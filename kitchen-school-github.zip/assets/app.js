
/* ============================================================
   Data — ingredients, gas marks
   ============================================================ */
const INGREDIENTS = [
  {name:"All-purpose flour", g:125},
  {name:"Bread flour", g:127},
  {name:"Whole-wheat flour", g:120},
  {name:"Granulated sugar", g:200},
  {name:"Brown sugar, packed", g:220},
  {name:"Powdered sugar", g:120},
  {name:"Butter", g:227},
  {name:"Milk", g:240},
  {name:"Water", g:236},
  {name:"Cocoa powder", g:85},
  {name:"Rolled oats", g:90},
  {name:"Uncooked white rice", g:185},
  {name:"Honey", g:340},
  {name:"Table salt", g:273}
];

const GAS_TABLE = [
  {gas:1, f:275, c:135},
  {gas:2, f:300, c:150},
  {gas:3, f:325, c:165},
  {gas:4, f:350, c:175},
  {gas:5, f:375, c:190},
  {gas:6, f:400, c:205},
  {gas:7, f:425, c:220},
  {gas:8, f:450, c:230},
  {gas:9, f:475, c:245}
];

/* ============================================================
   Data — course
   ============================================================ */
const MODULES = [
  {
    slug:"measure",
    num:"01",
    title:"Measuring & Conversions",
    dek:"Cups lie, scales don't. Build the habit that makes every other lesson work.",
    outcome:"Convert any recipe to grams and scale it without ruining the texture.",
    lessons:[
      {
        slug:"weight-vs-volume",
        title:"Why weight beats volume",
        dek:"A cup of flour is not a fixed amount. Here is the size of the error.",
        minutes:5,
        body:`
          <h2>Why it matters</h2>
          <p>A US cup of all-purpose flour can weigh anywhere from 110 g to 150 g depending on how it got into the cup. That is a 30% swing in the main ingredient of a cake, and no recipe can absorb it.</p>
          <p>Weight removes the variable. One gram is one gram whether the flour is loose, packed or humid.</p>
          <h2>Do this</h2>
          <ol>
            <li>Put the bowl on the scale first, then press tare so the display reads zero.</li>
            <li>Add the ingredient until the number matches the recipe — no scooping from the bag into the bowl.</li>
            <li>Use millilitres or grams for liquids; a liquid cup is far more consistent than a dry cup.</li>
          </ol>
          <h2>Mistakes to avoid</h2>
          <ul>
            <li>Packing brown sugar unless the recipe says "packed".</li>
            <li>Measuring over the mixing bowl — the overshoot goes in and cannot come out.</li>
            <li>Assuming a cup of every ingredient weighs the same. It never does.</li>
          </ul>`,
        practice:"Weigh one cup of flour twice: once scooped straight from the bag, once spooned in and levelled. Compare the numbers. That difference is your error budget.",
        tools:["cups-to-grams"]
      },
      {
        slug:"use-a-scale",
        title:"Using a scale without slowing down",
        dek:"Tare, target, done. The three-move routine that takes ten seconds.",
        minutes:4,
        body:`
          <h2>Why it matters</h2>
          <p>A $15 kitchen scale is more accurate than every measuring cup in your drawer. The only cost is learning a routine, and the routine is three moves.</p>
          <h2>Do this</h2>
          <ol>
            <li><b>Tare</b> with the empty bowl on the platform.</li>
            <li><b>Add</b> until you hit the target weight, watching the display rather than the bowl.</li>
            <li><b>Tare again</b> between ingredients and keep stacking in the same bowl.</li>
          </ol>
          <p>Use a 1 g resolution for flour, sugar and butter. For yeast and salt, a 0.1 g resolution matters more than the total capacity.</p>
          <h2>Mistakes to avoid</h2>
          <ul>
            <li>Forgetting to tare and counting the bowl weight as flour.</li>
            <li>Pouring fast near the target; slow down in the last 20 g.</li>
            <li>Trusting a scale that has not been checked — a 500 g bag of sugar makes a quick calibration test.</li>
          </ul>`,
        practice:"Convert a recipe that calls for 2¼ cups of flour into grams using the flour rate of 125 g per cup. Weigh it out and note how close the cup method would have been.",
        tools:["cups-to-grams"]
      },
      {
        slug:"scale-a-recipe",
        title:"Scaling a recipe up or down",
        dek:"Multiply the ingredients, then fix the pan and the clock — in that order.",
        minutes:6,
        body:`
          <h2>Why it matters</h2>
          <p>Doubling a recipe is not doubling every number. Ingredients scale linearly; pans do not, and baking time definitely does not.</p>
          <h2>Do this</h2>
          <ol>
            <li><b>Find the factor:</b> new servings ÷ original servings.</li>
            <li><b>Multiply every ingredient</b> by that factor, including salt and leaveners.</li>
            <li><b>Pick a pan with the same batter depth.</b> Area scales with the square of the diameter, not the diameter itself.</li>
            <li><b>Adjust time last.</b> A larger batch usually needs 5–10% longer at the same temperature.</li>
          </ol>
          <h2>Mistakes to avoid</h2>
          <ul>
            <li>Using a pan with double the diameter, which gives four times the area.</li>
            <li>Keeping the original bake time for a deeper pan.</li>
            <li>Scaling a pinch-based seasoning with the same precision as flour — taste, don't calculate.</li>
          </ul>`,
        practice:"Double an 8×8 brownie recipe, then choose between a 9×13 pan and two 8×8 pans. Work out the batter depth for each before you bake.",
        tools:["pan-size","cups-to-grams"]
      }
    ]
  },
  {
    slug:"heat",
    num:"02",
    title:"Heat & Ovens",
    dek:"Every oven lies a little. Learn the three modes and the two conversions that matter.",
    outcome:"Convert between oven, fan and air fryer settings without guessing.",
    lessons:[
      {
        slug:"oven-heat",
        title:"How oven heat actually works",
        dek:"Conduction, convection and radiation — and why the dial is an average.",
        minutes:5,
        body:`
          <h2>Why it matters</h2>
          <p>An oven does not hold a temperature; it cycles around one. The element switches on and off, and the air near the door is cooler than the air at the back. The dial is a target, not a measurement.</p>
          <h2>Do this</h2>
          <ol>
            <li>Preheat for a full 20 minutes, not the 8 minutes the display suggests.</li>
            <li>Place an oven thermometer in the middle and compare it with the dial.</li>
            <li>Learn the hot spot: toast sliced bread in one layer and see which corners brown first.</li>
          </ol>
          <p><b>Conduction</b> comes from the pan, <b>convection</b> from moving air, <b>radiation</b> from the element. A dark pan absorbs radiation faster; a light pan bakes more gently.</p>
          <h2>Mistakes to avoid</h2>
          <ul>
            <li>Opening the door to "check" in the first half of a bake — the temperature can drop 30°F.</li>
            <li>Trusting a 20-year-old thermostat.</li>
            <li>Baking two trays at once without rotating them halfway.</li>
          </ul>`,
        practice:"Run the bread test: one layer of sliced bread on a middle rack, 350°F for 6 minutes. Photograph the tray and mark the dark corners.",
        tools:["oven-temperature"]
      },
      {
        slug:"oven-vs-air-fryer",
        title:"Oven vs air fryer: the 25°F rule",
        dek:"One temperature drop, one time cut, one early check.",
        minutes:5,
        body:`
          <h2>Why it matters</h2>
          <p>An air fryer is a small, fast convection oven. The same recipe will overcook if you keep the oven's numbers, and undercook if you cut too much.</p>
          <h2>Do this</h2>
          <ol>
            <li>Drop the temperature by 25°F (15°C).</li>
            <li>Cut the time by 20%.</li>
            <li>Check at about 80% of the new time; add minutes only after that.</li>
          </ol>
          <p>If the original recipe was written for a fan-assisted oven, the temperature is already reduced — keep it and cut only the time.</p>
          <h2>Mistakes to avoid</h2>
          <ul>
            <li>Crowding the basket: stacked food steams instead of browning.</li>
            <li>Converting a 3-hour braise. Long, wet cooking is not an air fryer job.</li>
            <li>Assuming every air fryer runs at the same real temperature; the first batch is the calibration.</li>
          </ul>`,
        practice:"Convert a 425°F / 25-minute oven roast. Set the air fryer to the converted temperature and check at 80% of the converted time.",
        tools:["air-fryer","oven-temperature"]
      },
      {
        slug:"read-your-oven",
        title:"Reading fan, gas and hot spots",
        dek:"Fan settings, gas marks and the 20°C offset, decoded.",
        minutes:4,
        body:`
          <h2>Why it matters</h2>
          <p>Recipes travel between countries with different dials. A fan oven set to 180°C is not a conventional oven set to 180°C, and gas mark 4 is not a number you can calculate from scratch.</p>
          <h2>Do this</h2>
          <ol>
            <li><b>Fan:</b> set the dial about 20°C (35°F) lower than a conventional recipe says.</li>
            <li><b>Gas:</b> use the standard table — mark 4 is 350°F / 175°C; mark 6 is 400°F / 205°C.</li>
            <li><b>Hot spots:</b> rotate the tray halfway through, and use the back half for the item that needs the most color.</li>
          </ol>
          <h2>Mistakes to avoid</h2>
          <ul>
            <li>Converting gas marks with arithmetic instead of the table.</li>
            <li>Using the fan setting for delicate custards without lowering the temperature.</li>
            <li>Assuming the top rack is the hottest — it usually is, but the element position decides.</li>
          </ul>`,
        practice:"Find the fan conversion for three recipes written at 180°C, 200°C and 220°C. Write the dial settings you would actually use.",
        tools:["oven-temperature"]
      }
    ]
  },
  {
    slug:"pans",
    num:"03",
    title:"Pans & Baking",
    dek:"Area decides whether the batter fits; depth decides whether it bakes.",
    outcome:"Swap pans and adjust time with math instead of hope.",
    lessons:[
      {
        slug:"pan-area",
        title:"Pan area math that matters",
        dek:"πr² in one minute, and why 8-inch round ≠ 8-inch square.",
        minutes:5,
        body:`
          <h2>Why it matters</h2>
          <p>Recipes are written for a pan's volume, and volume starts with area. Two pans with the same width number can hold very different amounts.</p>
          <h2>Do this</h2>
          <ol>
            <li><b>Round:</b> area = π × (diameter ÷ 2)². An 8-inch round is about 50 in².</li>
            <li><b>Square:</b> area = side × side. An 8-inch square is 64 in².</li>
            <li><b>Rectangle:</b> area = length × width. A 9×13 is 117 in².</li>
          </ol>
          <p>Divide the new area by the old area to get the ingredient multiplier. Keep the batter depth close to the original.</p>
          <h2>Mistakes to avoid</h2>
          <ul>
            <li>Comparing diameter to side length as if they were the same measurement.</li>
            <li>Ignoring depth: a wider, shallower pan bakes faster and drier.</li>
            <li>Scaling a recipe by pan volume when you only know the width.</li>
          </ul>`,
        practice:"Calculate the areas of an 8-inch round, a 9-inch round and an 8-inch square. Rank them from smallest to largest before checking the tool.",
        tools:["pan-size"]
      },
      {
        slug:"swap-pans",
        title:"Substituting pans without ruining the bake",
        dek:"Match area, keep depth, then move the clock — not the other way around.",
        minutes:6,
        body:`
          <h2>Why it matters</h2>
          <p>A pan substitution is a geometry problem with a baking consequence. Get the area right and the batch fits; get the depth wrong and the texture changes.</p>
          <h2>Do this</h2>
          <ol>
            <li>Calculate both areas and the multiplier.</li>
            <li>Choose a pan where the batter depth stays within about 1 inch of the original.</li>
            <li>If the new pan is deeper, lower the temperature by 10–15°F and add time.</li>
            <li>If it is shallower, start checking earlier — often 10 minutes earlier.</li>
          </ol>
          <h2>Mistakes to avoid</h2>
          <ul>
            <li>Swapping a springform for a loose-bottom pan in a water bath.</li>
            <li>Filling a pan more than two-thirds full; leave room for rise.</li>
            <li>Changing pan and temperature at the same time, then not knowing which caused the result.</li>
          </ul>`,
        practice:"Take a recipe written for a 9-inch round and plan a bake in an 8-inch square. Write the multiplier, the expected depth and the time adjustment.",
        tools:["pan-size"]
      },
      {
        slug:"line-and-grease",
        title:"Lining and greasing: when each matters",
        dek:"Parchment, butter and flour are not interchangeable.",
        minutes:4,
        body:`
          <h2>Why it matters</h2>
          <p>The lining decides whether the crust releases cleanly and how the edge browns. The wrong choice shows up as a stuck cake or a soggy base.</p>
          <h2>Do this</h2>
          <ol>
            <li><b>Cakes:</b> grease the pan, line the bottom with parchment, grease again.</li>
            <li><b>Brownies and bars:</b> parchment with an overhang makes removal trivial.</li>
            <li><b>Bread:</b> grease and flour, or simply grease if the dough is high-hydration.</li>
            <li><b>Cheesecake:</b> parchment on the base only; grease the sides lightly.</li>
          </ol>
          <h2>Mistakes to avoid</h2>
          <ul>
            <li>Using flour on a pan for a flourless cake.</li>
            <li>Greasing only the middle and leaving the corners dry.</li>
            <li>Spraying oil on a hot pan — it burns before the batter arrives.</li>
          </ul>`,
        practice:"Pick a lining method for a sponge cake, a brownie tray and a sourdough loaf. Write one reason for each choice.",
        tools:["pan-size"]
      }
    ]
  },
  {
    slug:"dough",
    num:"04",
    title:"Dough & Bread",
    dek:"Flour, water, time. Three variables explain almost every dough problem.",
    outcome:"Read a dough formula and adjust hydration with confidence.",
    lessons:[
      {
        slug:"hydration",
        title:"Flour, water and baker's percentages",
        dek:"Why every bread formula starts at 100% flour.",
        minutes:6,
        body:`
          <h2>Why it matters</h2>
          <p>Baker's percentages make recipes comparable. Flour is always 100%, and every other ingredient is a share of that flour weight. A 65% hydration dough has 65 g of water for every 100 g of flour, regardless of batch size.</p>
          <h2>Do this</h2>
          <ol>
            <li>Weigh the flour and call it 100%.</li>
            <li>Set water as a percentage: 60% for a firm dough, 65% for an easy open, 75%+ for a wet dough.</li>
            <li>Add salt at 2% and instant yeast at 0.5–1% for a same-day rise.</li>
          </ol>
          <p>Flour protein matters too: bread flour (12–13%) holds more water than all-purpose (10–11%), and 00 flour behaves differently again.</p>
          <h2>Mistakes to avoid</h2>
          <ul>
            <li>Treating hydration as a fixed number across flour types.</li>
            <li>Adding water without holding back 5% for the flour's actual absorption.</li>
            <li>Scaling salt down when halving a recipe — salt percentages stay the same.</li>
          </ul>`,
        practice:"Write a 65% formula for 500 g of flour: water, salt and yeast in grams. Then convert it to a 1,000 g batch without changing the percentages.",
        tools:["pizza-dough"]
      },
      {
        slug:"knead-and-rest",
        title:"Kneading, resting and gluten",
        dek:"The dough does most of the work while you do nothing.",
        minutes:5,
        body:`
          <h2>Why it matters</h2>
          <p>Gluten develops through two mechanisms: mechanical work and time. Kneading is the fast route; resting is the cheap one. Most home bakers knead too much and rest too little.</p>
          <h2>Do this</h2>
          <ol>
            <li><b>Autolyse:</b> mix flour and water, rest 20–30 minutes before adding salt and yeast.</li>
            <li><b>Knead</b> until the dough is smooth and passes a gentle windowpane test.</li>
            <li><b>Stretch and fold</b> every 30 minutes during bulk fermentation instead of kneading longer.</li>
          </ol>
          <h2>Mistakes to avoid</h2>
          <ul>
            <li>Adding flour to a sticky dough before it has had time to hydrate.</li>
            <li>Kneading a wet dough on an unfloured counter until it tears.</li>
            <li>Judging the dough only by time; temperature changes the schedule.</li>
          </ul>`,
        practice:"Mix a dough at 65% hydration and rest it 20 minutes before kneading. Note how much less flour you need to keep it moving.",
        tools:["pizza-dough"]
      },
      {
        slug:"ferment",
        title:"Fermentation: bulk, proof and cold retard",
        dek:"Two rises, two jobs — and the fridge is a tool, not a delay.",
        minutes:5,
        body:`
          <h2>Why it matters</h2>
          <p>Bulk fermentation builds flavor and structure; the final proof decides the crumb. Doing both at room temperature is fast and less tasty. A cold retard separates them.</p>
          <h2>Do this</h2>
          <ol>
            <li><b>Bulk:</b> room temperature until the dough is 50–70% larger, with folds every 30 minutes.</li>
            <li><b>Shape</b> and refrigerate for 12–48 hours for flavor and an easier bake.</li>
            <li><b>Proof</b> at room temperature until a finger press springs back slowly.</li>
          </ol>
          <h2>Mistakes to avoid</h2>
          <ul>
            <li>Judging bulk by clock alone; dough temperature is the real variable.</li>
            <li>Baking cold dough straight from the fridge without a final proof.</li>
            <li>Letting the proof go until it collapses — over-proofed dough bakes flat.</li>
          </ul>`,
        practice:"Ferment one dough at room temperature and one in the fridge for 24 hours. Bake both and compare the crust color and crumb.",
        tools:["pizza-dough","oven-temperature"]
      }
    ]
  },
  {
    slug:"safety",
    num:"05",
    title:"Food Safety",
    dek:"Four numbers and two habits cover almost everything that matters.",
    outcome:"Thaw, cook and reheat food without gambling on the danger zone.",
    lessons:[
      {
        slug:"thaw-safely",
        title:"Thawing: fridge, water, microwave",
        dek:"The counter is never a thawing method.",
        minutes:5,
        body:`
          <h2>Why it matters</h2>
          <p>Frozen food thawed at room temperature spends hours in the danger zone (40–140°F / 4–60°C) while the center is still solid. Bacteria grow on the outside before the inside is usable.</p>
          <h2>Do this</h2>
          <ol>
            <li><b>Fridge:</b> about 24 hours per 5 lb, on the lowest shelf.</li>
            <li><b>Cold water:</b> sealed package, submerged, about 30 minutes per lb, water changed every 30 minutes.</li>
            <li><b>Microwave:</b> about 7 minutes per lb, then cook immediately.</li>
          </ol>
          <h2>Mistakes to avoid</h2>
          <ul>
            <li>Refreezing water-thawed meat without cooking it first.</li>
            <li>Using hot water to speed things up — it warms the surface into the danger zone.</li>
            <li>Leaving a thawed bird in the fridge for a week; cook within 1–2 days.</li>
          </ul>`,
        practice:"Plan a 5 lb chicken: write the fridge start time and the earliest safe cooking time, then compare with the thawing calculator.",
        tools:["thawing-time"]
      },
      {
        slug:"doneness",
        title:"Doneness temperatures that replace guesswork",
        dek:"Color is not a temperature. Four numbers to remember.",
        minutes:5,
        body:`
          <h2>Why it matters</h2>
          <p>Cutting into meat to check color loses juice and still does not prove safety. An instant-read thermometer settles both questions in three seconds.</p>
          <h2>Do this</h2>
          <ol>
            <li><b>Poultry, all parts:</b> 165°F / 74°C.</li>
            <li><b>Ground meat:</b> 160°F / 71°C.</li>
            <li><b>Whole beef, pork, lamb:</b> 145°F / 63°C, then rest 3 minutes.</li>
            <li><b>Fish:</b> 145°F / 63°C, or until it flakes.</li>
          </ol>
          <p>Measure the thickest part, away from bone and fat, and wait for the reading to settle.</p>
          <h2>Mistakes to avoid</h2>
          <ul>
            <li>Checking the surface of a thick piece instead of the center.</li>
            <li>Assuming carry-over cooking will finish the job with no rest.</li>
            <li>Using a thermometer that has not been calibrated in ice water.</li>
          </ul>`,
        practice:"Calibrate your thermometer in ice water (32°F / 0°C), then temp a chicken thigh in two places and compare the readings.",
        tools:["oven-temperature","thawing-time"]
      },
      {
        slug:"cool-and-reheat",
        title:"Cooling and reheating leftovers",
        dek:"Two hours to the fridge, 165°F to the plate.",
        minutes:4,
        body:`
          <h2>Why it matters</h2>
          <p>Most foodborne illness at home comes from slow cooling and uneven reheating, not from undercooking. Both are easy to fix with a clock and a thermometer.</p>
          <h2>Do this</h2>
          <ol>
            <li>Get leftovers into shallow containers within 2 hours of cooking.</li>
            <li>Cool uncovered in the fridge until cold, then cover.</li>
            <li>Reheat to 165°F / 74°C, stirring so there are no cold spots.</li>
            <li>Reheat rice once, and only if it was refrigerated promptly.</li>
          </ol>
          <h2>Mistakes to avoid</h2>
          <ul>
            <li>Putting a large hot pot straight into the fridge — the center cools too slowly.</li>
            <li>Reheating by look or steam instead of temperature.</li>
            <li>Keeping leftovers more than 3–4 days.</li>
          </ul>`,
        practice:"Audit your fridge: find one container older than four days and one that was cooled in a deep pot. Fix both habits this week.",
        tools:["thawing-time"]
      }
    ]
  },
  {
    slug:"coffee",
    num:"06",
    title:"Coffee & Drinks",
    dek:"Dose, grind, water. Three dials, in that order.",
    outcome:"Brew a repeatable cup and know which dial to turn when it tastes wrong.",
    lessons:[
      {
        slug:"coffee-ratio",
        title:"Ratios and doses",
        dek:"One number gets you most of the way to a good cup.",
        minutes:4,
        body:`
          <h2>Why it matters</h2>
          <p>Coffee strength is a ratio, not a scoop count. Once you know the ratio, changing the cup size is arithmetic instead of trial.</p>
          <h2>Do this</h2>
          <ol>
            <li>Weigh the coffee: 18 g is a common single mug dose.</li>
            <li>Start at 1:16 — 18 g coffee to 288 g water.</li>
            <li>Adjust to taste in small steps: 1:15 stronger, 1:17 lighter.</li>
          </ol>
          <p>Water in grams equals water in millilitres, so a scale on the brewer is enough.</p>
          <h2>Mistakes to avoid</h2>
          <ul>
            <li>Changing ratio and grind at the same time.</li>
            <li>Using volume scoops for coffee and assuming they are consistent.</li>
            <li>Confusing espresso ratios (about 1:2) with filter ratios.</li>
          </ul>`,
        practice:"Brew the same coffee at 1:15 and 1:17 with everything else fixed. Taste both and write one sentence about the difference.",
        tools:["coffee-ratio"]
      },
      {
        slug:"grind-size",
        title:"Grind size and extraction",
        dek:"Sour is usually under-extracted; bitter is usually over-extracted.",
        minutes:5,
        body:`
          <h2>Why it matters</h2>
          <p>Grind size controls how fast water reaches the coffee. Too coarse and the cup is weak and sour; too fine and it turns bitter and muddy.</p>
          <h2>Do this</h2>
          <ol>
            <li>Match grind to method: coarse for French press, medium for drip, fine for espresso.</li>
            <li>Change one click at a time and keep the dose and ratio fixed.</li>
            <li>If the brew stalls or drains too fast, adjust grind before adjusting ratio.</li>
          </ol>
          <h2>Mistakes to avoid</h2>
          <ul>
            <li>Buying pre-ground coffee and expecting to dial in a pour-over.</li>
            <li>Grinding too fine to "get more flavor" — extraction is not extraction rate.</li>
            <li>Changing beans and grind together.</li>
          </ul>`,
        practice:"Take one coffee and brew it one grind setting finer than usual. Keep the dose and water the same, then compare drawdown time and taste.",
        tools:["coffee-ratio"]
      },
      {
        slug:"water-temp",
        title:"Water and temperature",
        dek:"90–96°C, and why your kettle is not there yet.",
        minutes:4,
        body:`
          <h2>Why it matters</h2>
          <p>Water is more than 98% of the cup. Its temperature sets the extraction speed, and its mineral content changes how the coffee tastes.</p>
          <h2>Do this</h2>
          <ol>
            <li>Brew filter coffee at 90–96°C / 194–205°F.</li>
            <li>Off the boil, rest the kettle 30–45 seconds before pouring.</li>
            <li>Rinse the filter with hot water to remove paper taste, then brew.</li>
          </ol>
          <p>Hard water mutes flavor; very soft water makes the cup taste flat. If your tap water is heavily chlorinated, use filtered water.</p>
          <h2>Mistakes to avoid</h2>
          <ul>
            <li>Pouring straight off a rolling boil onto light-roast coffee.</li>
            <li>Using the same temperature for dark and light roasts.</li>
            <li>Ignoring water because "it is just water".</li>
          </ul>`,
        practice:"Brew two cups with water at boiling and at 30 seconds off the boil. Keep everything else identical and note which is more bitter.",
        tools:["coffee-ratio"]
      }
    ]
  }
];

const LESSONS = MODULES.flatMap(m => m.lessons.map((l, i) => ({ ...l, module: m, index: i + 1 })));

/* ============================================================
   Data — reference charts
   ============================================================ */
const REFERENCES = [
  {
    slug:"grams-per-cup",
    title:"Grams per cup chart",
    dek:"The weight of one US cup for fourteen common ingredients.",
    intro:"A cup is volume, so the weight depends on the ingredient. These values assume a level cup, spooned in rather than scooped.",
    headers:["Ingredient","Grams per cup"],
    rows:INGREDIENTS.map(x=>[x.name, x.g]),
    numeric:[1],
    notes:"US cup = 240 ml. For anything not listed, use the cups-to-grams converter and enter the density if you know it.",
    tools:["cups-to-grams"]
  },
  {
    slug:"oven-temperatures",
    title:"Oven temperature chart",
    dek:"Fahrenheit, Celsius, gas marks and fan settings in one table.",
    intro:"Gas marks are a scale, not a temperature. Use the row that matches the mark, then adjust for a fan oven by subtracting 20°C.",
    headers:["Gas mark","°F","°C","Fan °C"],
    rows:GAS_TABLE.map(x=>[x.gas, x.f, x.c, x.c-20]),
    numeric:[1,2,3],
    notes:"Most recipe books round to these marks. An oven thermometer is the only reliable check of what your oven actually does.",
    tools:["oven-temperature","air-fryer"]
  },
  {
    slug:"butter-measurements",
    title:"Butter measurements",
    dek:"Sticks, cups, grams, tablespoons and ounces.",
    intro:"One US stick is the anchor: 113 g, ½ cup, 8 tablespoons, 4 ounces. Everything else follows from it.",
    headers:["Butter amount","Grams","Tablespoons","Ounces"],
    rows:[
      ["1 tablespoon",14,1,0.5],
      ["¼ cup / ½ stick",57,4,2],
      ["½ cup / 1 stick",113,8,4],
      ["1 cup / 2 sticks",227,16,8],
      ["250 g block",250,17.6,8.8]
    ],
    numeric:[1,2,3],
    notes:"European blocks are usually 250 g — slightly more than two US sticks. For melted butter, measure after melting.",
    tools:["butter"]
  },
  {
    slug:"pan-sizes",
    title:"Common pan sizes and areas",
    dek:"Square inches for the pans most recipes call for.",
    intro:"Area is the number that decides whether a recipe fits. Depth decides how it bakes. These figures assume the standard depth for each pan type.",
    headers:["Pan","Area (in²)","Area (cm²)","Typical use"],
    rows:[
      ["6-inch round",28,183,"Small cake"],
      ["8-inch round",50,324,"Layer cake"],
      ["9-inch round",64,412,"Layer cake, tart"],
      ["8-inch square",64,412,"Brownies, cake"],
      ["9-inch square",81,523,"Brownies, cake"],
      ["9×13 inch",117,755,"Sheet cake, roast"],
      ["8×8 inch",64,412,"Brownies, cake"]
    ],
    numeric:[1,2],
    notes:"Convert area to a multiplier by dividing the new area by the original. Keep batter depth within about 1 inch.",
    tools:["pan-size"]
  },
  {
    slug:"meat-doneness",
    title:"Meat doneness temperatures",
    dek:"The safe internal temperatures, in Fahrenheit and Celsius.",
    intro:"These are the USDA minimum safe temperatures. Measure the thickest part, away from bone, and let the reading settle.",
    headers:["Food","°F","°C","Rest"],
    rows:[
      ["Poultry (all parts)",165,74,"None"],
      ["Ground meat",160,71,"None"],
      ["Whole beef / pork / lamb",145,63,"3 minutes"],
      ["Fish",145,63,"None"],
      ["Leftovers (reheat)",165,74,"None"]
    ],
    numeric:[1,2],
    notes:"Carry-over cooking continues during rest. Pull whole meat 3–5°F below target if you plan to rest it.",
    tools:["thawing-time","oven-temperature"]
  },
  {
    slug:"coffee-ratios",
    title:"Coffee ratio chart",
    dek:"Dose and water for the common filter ratios.",
    intro:"Filter coffee is measured by weight. These ratios assume medium grind and a 90–96°C brew temperature.",
    headers:["Ratio","18 g coffee","Water","Style"],
    rows:[
      ["1:15",18,"270 g","Strong"],
      ["1:16",18,"288 g","Balanced"],
      ["1:17",18,"306 g","Light"],
      ["1:18",18,"324 g","Tea-like"]
    ],
    numeric:[2],
    notes:"Espresso uses a much tighter ratio, around 1:2. This chart is for drip, pour-over and French press.",
    tools:["coffee-ratio"]
  }
];

/* ============================================================
   Data — tools
   ============================================================ */
const TOOLS = [
  {
    slug:"air-fryer",
    cat:"Heat",
    title:"Air Fryer Time & Temperature Converter",
    card:"Turn an oven recipe into an air fryer setting — and back.",
    lede:"Air fryers run hotter and faster than ovens. This converter adjusts both temperature and time, so an oven recipe works in the basket.",
    related:["oven-temperature","thawing-time","pan-size"],
    ui(){
      return `
      <section class="calc" aria-label="Air fryer converter">
        <div class="calc-top">
          <p class="calc-label">CONVERT</p>
          <div class="seg" id="af-dir">
            <button class="seg-btn is-on" type="button" data-val="o2a">Oven → Air fryer</button>
            <button class="seg-btn" type="button" data-val="a2o">Air fryer → Oven</button>
          </div>
        </div>
        <div class="calc-grid">
          <label class="field">
            <span class="field-label">Oven temperature</span>
            <div class="field-row">
              <input id="af-temp" type="number" inputmode="decimal" value="400" step="5" min="0">
              <div class="seg seg-sm" id="af-unit">
                <button class="seg-btn is-on" type="button" data-val="F">°F</button>
                <button class="seg-btn" type="button" data-val="C">°C</button>
              </div>
            </div>
          </label>
          <label class="field">
            <span class="field-label">Oven time (minutes)</span>
            <input id="af-time" type="number" inputmode="decimal" value="30" step="1" min="0">
          </label>
        </div>
        <div class="result">
          <div class="stat"><p class="stat-label">Temperature</p><p class="stat-value"><span id="af-rtemp">375</span><small id="af-runit">°F</small></p></div>
          <div class="stat"><p class="stat-label">Time</p><p class="stat-value"><span id="af-rmin">24</span><small>min</small></p></div>
        </div>
        <p class="calc-note" id="af-note">Start checking at 19 minutes.</p>
        <div class="calc-actions"><button class="btn btn-ghost" type="button" id="af-copy">Copy result</button></div>
      </section>`;
    },
    mount(root){
      let dir="o2a", unit=isMetric()?"C":"F";
      const tempEl=root.querySelector("#af-temp"), timeEl=root.querySelector("#af-time");
      const tOut=root.querySelector("#af-rtemp"), uOut=root.querySelector("#af-runit"),
            mOut=root.querySelector("#af-rmin"), note=root.querySelector("#af-note");
      if(isMetric()){
        tempEl.value=200;
        root.querySelectorAll("#af-unit .seg-btn").forEach(b=>b.classList.toggle("is-on", b.dataset.val==="C"));
      }
      seg(root.querySelector("#af-dir"), v=>{dir=v; calc();});
      seg(root.querySelector("#af-unit"), v=>{unit=v; calc();});
      function calc(){
        let t=num(tempEl.value), m=num(timeEl.value);
        if(t<=0 || m<=0){ tOut.textContent="—"; mOut.textContent="—"; note.textContent=LANG==="zh"?"请输入温度和时间。":"Enter a temperature and a time."; return; }
        const delta = unit==="F" ? 25 : 15;
        let outT = dir==="o2a" ? t-delta : t+delta;
        let outM = dir==="o2a" ? m*0.8 : m/0.8;
        outT = Math.max(0, Math.round(outT/5)*5);
        outM = Math.max(1, Math.round(outM));
        tOut.textContent=fmt(outT); uOut.textContent="°"+unit; mOut.textContent=fmt(outM);
        const check=Math.max(1, Math.round(outM*0.8));
        if(LANG==="zh"){
          note.textContent = dir==="o2a"
            ? `空气炸锅设为 ${fmt(outT)}°${unit}，烤 ${fmt(outM)} 分钟，从 ${fmt(check)} 分钟开始检查。`
            : `烤箱设为 ${fmt(outT)}°${unit}，烤 ${fmt(outM)} 分钟，从 ${fmt(check)} 分钟开始检查。`;
        }else{
          note.textContent = dir==="o2a"
            ? `Set the air fryer to ${fmt(outT)}°${unit} for ${fmt(outM)} minutes. Start checking at ${fmt(check)} minutes.`
            : `Set the oven to ${fmt(outT)}°${unit} for ${fmt(outM)} minutes. Start checking at ${fmt(check)} minutes.`;
        }
      }
      tempEl.addEventListener("input",calc);
      timeEl.addEventListener("input",calc);
      wireCopy(root.querySelector("#af-copy"), ()=>{
        const label=LANG==="zh"?(dir==="o2a"?"空气炸锅":"烤箱"):(dir==="o2a"?"Air fryer":"Oven");
        return `${label}: ${tOut.textContent}°${unit} · ${mOut.textContent} min`;
      });
      calc();
    }
  },
  {
    slug:"cups-to-grams",
    cat:"Weight",
    title:"Cups to Grams Converter",
    card:"A cup of flour is not a cup of sugar. Convert by ingredient.",
    lede:"A cup measures volume; a gram measures weight. The same cup holds very different amounts of flour, sugar and honey. Pick the ingredient and convert both ways.",
    related:["butter","pan-size","pizza-dough"],
    ui(){
      const opts=INGREDIENTS.map((x,i)=>`<option value="${i}">${x.name}</option>`).join("");
      return `
      <section class="calc" aria-label="Cups to grams converter">
        <div class="calc-top">
          <p class="calc-label">CONVERT</p>
          <div class="seg" id="cg-dir">
            <button class="seg-btn is-on" type="button" data-val="c2g">Cups → grams</button>
            <button class="seg-btn" type="button" data-val="g2c">Grams → cups</button>
          </div>
        </div>
        <div class="calc-grid">
          <label class="field">
            <span class="field-label">Ingredient</span>
            <select id="cg-ing">${opts}</select>
          </label>
          <label class="field">
            <span class="field-label" id="cg-amt-label">Amount (cups)</span>
            <input id="cg-amt" type="number" inputmode="decimal" value="1" step="0.25" min="0">
          </label>
        </div>
        <div class="result">
          <div class="stat">
            <p class="stat-label" id="cg-out-label">Weight</p>
            <p class="stat-value"><span id="cg-out">125</span><small id="cg-unit">g</small></p>
            <p class="stat-sub" id="cg-sub">1 cup of all-purpose flour = 125 g</p>
          </div>
          <div class="stat">
            <p class="stat-label">Reference</p>
            <p class="stat-value"><span id="cg-ref">125</span><small>g / cup</small></p>
            <p class="stat-sub">US cup = 240 ml</p>
          </div>
        </div>
        <p class="calc-note">Spoon the flour into the cup and level it. Scooping straight from the bag compacts it and can add 15–20%.</p>
        <div class="calc-actions"><button class="btn btn-ghost" type="button" id="cg-copy">Copy result</button></div>
      </section>`;
    },
    mount(root){
      let dir="c2g";
      const ing=root.querySelector("#cg-ing"), amt=root.querySelector("#cg-amt");
      const out=root.querySelector("#cg-out"), unit=root.querySelector("#cg-unit"),
            sub=root.querySelector("#cg-sub"), label=root.querySelector("#cg-amt-label"),
            outLabel=root.querySelector("#cg-out-label"), ref=root.querySelector("#cg-ref");
      seg(root.querySelector("#cg-dir"), v=>{
        dir=v;
        label.textContent = v==="c2g" ? "Amount (cups)" : "Amount (grams)";
        outLabel.textContent = v==="c2g" ? "Weight" : "Volume";
        amt.value = v==="c2g" ? "1" : String(INGREDIENTS[Number(ing.value)].g);
        calc();
      });
      function calc(){
        const item=INGREDIENTS[Number(ing.value)];
        const v=num(amt.value);
        ref.textContent=fmt(item.g);
        if(v<=0){ out.textContent="—"; sub.textContent=LANG==="zh"?"请输入大于零的数量。":"Enter an amount above zero."; return; }
        if(dir==="c2g"){ out.textContent=fmt(v*item.g); unit.textContent="g"; }
        else{ out.textContent=fmt(v/item.g,2); unit.textContent="cups"; }
        sub.textContent = LANG==="zh"
          ? `1 杯${tn(item.name)} = ${fmt(item.g)} 克`
          : `1 cup of ${item.name.toLowerCase()} = ${fmt(item.g)} g`;
      }
      ing.addEventListener("change",calc);
      amt.addEventListener("input",calc);
      wireCopy(root.querySelector("#cg-copy"), ()=>`${amt.value} ${dir==="c2g"?(LANG==="zh"?"杯":"cup(s)"):"g"} = ${out.textContent} ${unit.textContent} (${tn(INGREDIENTS[Number(ing.value)].name)})`);
      calc();
    }
  },
  {
    slug:"butter",
    cat:"Weight",
    title:"Butter Converter",
    card:"Sticks, cups, grams, tablespoons, ounces — one input, all five.",
    lede:"US recipes count butter in sticks. European blocks are weighed in grams. One input converts between sticks, cups, grams, tablespoons and ounces.",
    related:["cups-to-grams","pan-size","pizza-dough"],
    ui(){
      return `
      <section class="calc" aria-label="Butter converter">
        <div class="calc-top"><p class="calc-label">CONVERT</p><p class="calc-label" style="margin:0">1 stick = ½ cup = 8 tbsp = 113 g</p></div>
        <div class="calc-grid">
          <label class="field"><span class="field-label">Amount</span><input id="bt-amt" type="number" inputmode="decimal" value="1" step="0.25" min="0"></label>
          <label class="field"><span class="field-label">Unit</span>
            <select id="bt-unit">
              <option value="stick">Sticks</option>
              <option value="cup">Cups</option>
              <option value="g">Grams</option>
              <option value="tbsp">Tablespoons</option>
              <option value="oz">Ounces</option>
            </select>
          </label>
        </div>
        <div class="result result-5">
          <div class="stat"><p class="stat-label">Sticks</p><p class="stat-value"><span id="bt-stick">1</span></p></div>
          <div class="stat"><p class="stat-label">Cups</p><p class="stat-value"><span id="bt-cup">0.5</span></p></div>
          <div class="stat"><p class="stat-label">Grams</p><p class="stat-value"><span id="bt-g">113</span></p></div>
          <div class="stat"><p class="stat-label">Tablespoons</p><p class="stat-value"><span id="bt-tbsp">8</span></p></div>
          <div class="stat"><p class="stat-label">Ounces</p><p class="stat-value"><span id="bt-oz">4</span></p></div>
        </div>
        <p class="calc-note">For melted butter, measure after melting if the recipe specifies melted — volume changes slightly.</p>
        <div class="calc-actions"><button class="btn btn-ghost" type="button" id="bt-copy">Copy result</button></div>
      </section>`;
    },
    mount(root){
      const amt=root.querySelector("#bt-amt"), unit=root.querySelector("#bt-unit");
      const out={stick:root.querySelector("#bt-stick"),cup:root.querySelector("#bt-cup"),g:root.querySelector("#bt-g"),tbsp:root.querySelector("#bt-tbsp"),oz:root.querySelector("#bt-oz")};
      if(isMetric()){ unit.value="g"; amt.value="100"; }
      function calc(){
        const v=num(amt.value); let grams=0;
        switch(unit.value){
          case "stick": grams=v*113; break;
          case "cup": grams=v*227; break;
          case "g": grams=v; break;
          case "tbsp": grams=v*14.175; break;
          case "oz": grams=v*28.35; break;
        }
        out.g.textContent=fmt(grams);
        out.stick.textContent=fmt(grams/113,2);
        out.cup.textContent=fmt(grams/227,2);
        out.tbsp.textContent=fmt(grams/14.175,2);
        out.oz.textContent=fmt(grams/28.35,2);
      }
      amt.addEventListener("input",calc);
      unit.addEventListener("change",calc);
      wireCopy(root.querySelector("#bt-copy"), ()=>`${fmt(num(amt.value),2)} ${unit.value} = ${out.g.textContent} g butter (${out.stick.textContent} sticks)`);
      calc();
    }
  },
  {
    slug:"pan-size",
    cat:"Pans",
    title:"Pan Size Converter",
    card:"Scale a recipe for a different pan instead of guessing.",
    lede:"Two pans rarely hold the same amount of batter. Enter the original pan and the one you want to use, and get the area ratio to multiply every ingredient by.",
    related:["cups-to-grams","oven-temperature","pizza-dough"],
    ui(){
      return `
      <section class="calc" aria-label="Pan size converter">
        <div class="calc-top"><p class="calc-label">PAN A → PAN B</p></div>
        <div class="calc-grid">
          <label class="field"><span class="field-label">Original pan shape</span>
            <select id="pn-a-shape"><option value="round">Round</option><option value="square">Square</option><option value="rect">Rectangle</option></select>
          </label>
          <label class="field"><span class="field-label">New pan shape</span>
            <select id="pn-b-shape"><option value="round">Round</option><option value="square">Square</option><option value="rect">Rectangle</option></select>
          </label>
          <label class="field"><span class="field-label" id="pn-a-l1">Diameter (in)</span><input id="pn-a-d1" type="number" inputmode="decimal" value="8" step="0.5" min="0"></label>
          <label class="field"><span class="field-label" id="pn-b-l1">Diameter (in)</span><input id="pn-b-d1" type="number" inputmode="decimal" value="9" step="0.5" min="0"></label>
          <label class="field" id="pn-a-w-wrap" style="display:none"><span class="field-label">Width (in)</span><input id="pn-a-d2" type="number" inputmode="decimal" value="9" step="0.5" min="0"></label>
          <label class="field" id="pn-b-w-wrap" style="display:none"><span class="field-label">Width (in)</span><input id="pn-b-d2" type="number" inputmode="decimal" value="13" step="0.5" min="0"></label>
        </div>
        <div class="result">
          <div class="stat"><p class="stat-label">Multiply ingredients by</p><p class="stat-value"><span id="pn-ratio">1.27</span><small>×</small></p><p class="stat-sub" id="pn-areas">Pan A 50 in² → Pan B 64 in²</p></div>
          <div class="stat"><p class="stat-label">What this means</p><p class="stat-value" style="font-size:clamp(18px,2.6vw,26px);line-height:1.25" id="pn-msg">Use 27% more of everything.</p><p class="stat-sub">Assumes both pans are the same depth.</p></div>
        </div>
        <p class="calc-note">Keep the batter depth close to the original. A much deeper pan needs a longer bake at a lower temperature.</p>
        <div class="calc-actions"><button class="btn btn-ghost" type="button" id="pn-copy">Copy result</button></div>
      </section>`;
    },
    mount(root){
      const aShape=root.querySelector("#pn-a-shape"), bShape=root.querySelector("#pn-b-shape");
      const aD1=root.querySelector("#pn-a-d1"), bD1=root.querySelector("#pn-b-d1");
      const aD2=root.querySelector("#pn-a-d2"), bD2=root.querySelector("#pn-b-d2");
      const aW=root.querySelector("#pn-a-w-wrap"), bW=root.querySelector("#pn-b-w-wrap");
      const aL1=root.querySelector("#pn-a-l1"), bL1=root.querySelector("#pn-b-l1");
      const ratioEl=root.querySelector("#pn-ratio"), areas=root.querySelector("#pn-areas"), msg=root.querySelector("#pn-msg");
      function area(shape,d1,d2){
        if(d1<=0) return 0;
        if(shape==="round") return Math.PI*Math.pow(d1/2,2);
        if(shape==="square") return d1*d1;
        return d1*Math.max(d2,0);
      }
      function syncLabels(){
        const label=shape=> shape==="round"?"Diameter (in)": shape==="square"?"Side (in)":"Length (in)";
        aL1.textContent=label(aShape.value); bL1.textContent=label(bShape.value);
        aW.style.display = aShape.value==="rect" ? "block" : "none";
        bW.style.display = bShape.value==="rect" ? "block" : "none";
      }
      function calc(){
        const A=area(aShape.value,num(aD1.value),num(aD2.value));
        const B=area(bShape.value,num(bD1.value),num(bD2.value));
        if(A<=0 || B<=0){ ratioEl.textContent="—"; areas.textContent=LANG==="zh"?"请输入两个烤盘尺寸。":"Enter both pan sizes."; msg.textContent=""; return; }
        const r=B/A;
        ratioEl.textContent=fmt(r,2);
        areas.textContent = LANG==="zh"
          ? `原盘 ${fmt(A)} 平方英寸 → 新盘 ${fmt(B)} 平方英寸`
          : `Pan A ${fmt(A)} in² → Pan B ${fmt(B)} in²`;
        const pct=Math.round((r-1)*100);
        if(LANG==="zh"){
          msg.textContent = pct===0 ? "面积相同，不需要调整。" : pct>0 ? `所有食材乘以 ${ratioEl.textContent}（多 ${Math.abs(pct)}%）。` : `所有食材乘以 ${ratioEl.textContent}（少 ${Math.abs(pct)}%）。`;
        }else{
          msg.textContent = pct===0 ? "Same area — no change needed." : pct>0 ? `Use ${Math.abs(pct)}% more of everything.` : `Use ${Math.abs(pct)}% less of everything.`;
        }
      }
      [aShape,bShape].forEach(s=>s.addEventListener("change",()=>{syncLabels();calc();}));
      [aD1,aD2,bD1,bD2].forEach(i=>i.addEventListener("input",calc));
      wireCopy(root.querySelector("#pn-copy"), ()=>`Multiply ingredients by ${ratioEl.textContent}× for the new pan`);
      syncLabels(); calc();
    }
  },
  {
    slug:"oven-temperature",
    cat:"Heat",
    title:"Oven Temperature Converter",
    card:"Fahrenheit, Celsius, fan Celsius and gas marks in one view.",
    lede:"Oven dials disagree with each other and with recipes. Convert between Fahrenheit, Celsius, fan Celsius and gas marks in any direction.",
    related:["air-fryer","pan-size","pizza-dough"],
    ui(){
      const gasOpts=GAS_TABLE.map(x=>`<option value="${x.c}">Gas mark ${x.gas}</option>`).join("");
      return `
      <section class="calc" aria-label="Oven temperature converter">
        <div class="calc-top"><p class="calc-label">CONVERT</p></div>
        <div class="calc-grid">
          <label class="field"><span class="field-label">Temperature</span><input id="ov-val" type="number" inputmode="decimal" value="350" step="5" min="0"></label>
          <label class="field"><span class="field-label">Unit</span>
            <select id="ov-unit">
              <option value="F" selected>°F</option>
              <option value="C">°C</option>
              <option value="gas">Gas mark</option>
              <option value="fan">Fan °C</option>
            </select>
          </label>
        </div>
        <div class="result result-4">
          <div class="stat"><p class="stat-label">Fahrenheit</p><p class="stat-value"><span id="ov-f">350</span><small>°F</small></p></div>
          <div class="stat"><p class="stat-label">Celsius</p><p class="stat-value"><span id="ov-c">175</span><small>°C</small></p></div>
          <div class="stat"><p class="stat-label">Gas mark</p><p class="stat-value"><span id="ov-g">4</span></p></div>
          <div class="stat"><p class="stat-label">Fan °C</p><p class="stat-value"><span id="ov-fan">155</span><small>°C</small></p></div>
        </div>
        <p class="calc-note">Fan ovens usually run 20°C (35°F) hotter than the dial suggests. For delicate bakes, check with an oven thermometer.</p>
        <div class="calc-actions"><button class="btn btn-ghost" type="button" id="ov-copy">Copy result</button></div>
      </section>`;
    },
    mount(root){
      const val=root.querySelector("#ov-val"), unit=root.querySelector("#ov-unit");
      const f=root.querySelector("#ov-f"), c=root.querySelector("#ov-c"), g=root.querySelector("#ov-g"), fan=root.querySelector("#ov-fan");
      if(isMetric()){ val.value=175; unit.value="C"; }
      function nearestGas(celsius){
        let best=GAS_TABLE[0], d=Math.abs(best.c-celsius);
        GAS_TABLE.forEach(x=>{ const dd=Math.abs(x.c-celsius); if(dd<d){d=dd;best=x;} });
        return best;
      }
      function calc(){
        let celsius=NaN;
        const v=num(val.value);
        if(v<=0){ f.textContent="—";c.textContent="—";g.textContent="—";fan.textContent="—"; return; }
        if(unit.value==="F") celsius=(v-32)*5/9;
        else if(unit.value==="C") celsius=v;
        else if(unit.value==="fan") celsius=v+20;
        else if(unit.value==="gas"){ const row=GAS_TABLE.find(x=>x.gas===Math.round(v)); celsius = row ? row.c : NaN; }
        if(!isFinite(celsius)||celsius<50||celsius>320){ f.textContent="—";c.textContent="—";g.textContent="—";fan.textContent="—"; return; }
        const rawC=celsius, F=rawC*9/5+32;
        f.textContent=fmt(Math.round(F/25)*25);
        c.textContent=fmt(Math.round(rawC/5)*5);
        g.textContent=nearestGas(rawC).gas;
        fan.textContent=fmt(Math.round((rawC-20)/5)*5);
      }
      val.addEventListener("input",calc);
      unit.addEventListener("change",()=>{
        const current={F:f.textContent,C:c.textContent,gas:g.textContent,fan:fan.textContent};
        const next=current[unit.value];
        if(next && next!=="—") val.value=next;
        calc();
      });
      wireCopy(root.querySelector("#ov-copy"), ()=>`${f.textContent}°F / ${c.textContent}°C / gas ${g.textContent} / fan ${fan.textContent}°C`);
      calc();
    }
  },
  {
    slug:"thawing-time",
    cat:"Safety",
    title:"Thawing Time Calculator",
    card:"Safe thawing times in the fridge, cold water or microwave.",
    lede:"How long until frozen meat or poultry is safe to cook? Pick a method and a weight. These are the standard USDA rates, converted to usable times.",
    related:["air-fryer","oven-temperature","pan-size"],
    ui(){
      return `
      <section class="calc" aria-label="Thawing time calculator">
        <div class="calc-top"><p class="calc-label">ESTIMATE</p></div>
        <div class="calc-grid">
          <label class="field"><span class="field-label">Weight</span>
            <div class="field-row">
              <input id="th-w" type="number" inputmode="decimal" value="5" step="0.5" min="0">
              <div class="seg seg-sm" id="th-unit"><button class="seg-btn is-on" type="button" data-val="lb">lb</button><button class="seg-btn" type="button" data-val="kg">kg</button></div>
            </div>
          </label>
          <label class="field"><span class="field-label">Method</span>
            <select id="th-method"><option value="fridge">Refrigerator</option><option value="water">Cold water</option><option value="microwave">Microwave</option></select>
          </label>
        </div>
        <div class="result">
          <div class="stat"><p class="stat-label">Estimated time</p><p class="stat-value"><span id="th-out">1d</span><small id="th-unit-out"></small></p><p class="stat-sub" id="th-sub">About 1 day in the fridge.</p></div>
          <div class="stat"><p class="stat-label">Rule of thumb</p><p class="stat-value" style="font-size:clamp(18px,2.6vw,26px);line-height:1.25">24 hr per 5 lb</p><p class="stat-sub">Refrigerator method</p></div>
        </div>
        <p class="calc-note" id="th-note">Keep it on the lowest shelf and cook within 2 days of thawing.</p>
        <div class="calc-actions"><button class="btn btn-ghost" type="button" id="th-copy">Copy result</button></div>
      </section>`;
    },
    mount(root){
      let unit=isMetric()?"kg":"lb";
      const wEl=root.querySelector("#th-w"), method=root.querySelector("#th-method");
      const out=root.querySelector("#th-out"), unitOut=root.querySelector("#th-unit-out");
      const sub=root.querySelector("#th-sub"), note=root.querySelector("#th-note");
      if(isMetric()){
        wEl.value=2;
        root.querySelectorAll("#th-unit .seg-btn").forEach(b=>b.classList.toggle("is-on", b.dataset.val==="kg"));
      }
      seg(root.querySelector("#th-unit"), v=>{unit=v; calc();});
      function calc(){
        let lb=num(wEl.value);
        if(unit==="kg") lb=lb*2.20462;
        if(lb<=0){ out.textContent="—"; sub.textContent=LANG==="zh"?"请输入大于零的重量。":"Enter a weight above zero."; return; }
        let hours=0, mins=0;
        if(method.value==="fridge") hours=lb*4.8;
        if(method.value==="water") mins=lb*30;
        if(method.value==="microwave") mins=lb*7;
        const totalMins=Math.round(hours*60+mins);
        if(totalMins>=1440){
          let d=Math.floor(totalMins/1440), h=Math.round((totalMins%1440)/60);
          if(h===24){ d+=1; h=0; }
          out.textContent = h===0 ? `${d}d` : `${d}d ${h}h`; unitOut.textContent="";
          sub.textContent = LANG==="zh"
            ? `约 ${d} 天${h>0?` ${h} 小时`:""}（冷藏）。`
            : `About ${d} day${d>1?"s":""}${h>0?` ${h} hour${h===1?"":"s"}`:""} in the fridge.`;
        }else if(totalMins>=60){
          const h=Math.floor(totalMins/60), m=totalMins%60;
          out.textContent=`${h}h ${m}m`; unitOut.textContent="";
          sub.textContent = LANG==="zh"
            ? (method.value==="microwave" ? "微波后立刻烹饪。" : "每 30 分钟换一次水。")
            : (method.value==="microwave" ? "Cook immediately after microwaving." : "Change the water every 30 minutes.");
        }else{
          out.textContent=totalMins; unitOut.textContent="min";
          sub.textContent = LANG==="zh"
            ? (method.value==="microwave" ? "微波后立刻烹饪。" : "每 30 分钟换一次水。")
            : (method.value==="microwave" ? "Cook immediately after microwaving." : "Change the water every 30 minutes.");
        }
        if(LANG==="zh"){
          note.textContent = method.value==="fridge" ? "放最下层，解冻后 2 天内做熟。"
            : method.value==="water" ? "食物保持密封并完全浸没；每 30 分钟换水。"
            : "微波解冻会先加热边缘——取出后立刻烹饪。";
        }else{
          note.textContent = method.value==="fridge" ? "Keep it on the lowest shelf and cook within 2 days of thawing."
            : method.value==="water" ? "Keep the food sealed and submerged; change the water every 30 minutes."
            : "Microwave thawing starts cooking the edges — cook the food right away.";
        }
      }
      wEl.addEventListener("input",calc);
      method.addEventListener("change",calc);
      wireCopy(root.querySelector("#th-copy"), ()=>(LANG==="zh"?"解冻 ":"Thaw ")+`${wEl.value} ${unit} · ${out.textContent}${unitOut.textContent}`);
      calc();
    }
  },
  {
    slug:"coffee-ratio",
    cat:"Brew",
    title:"Coffee Ratio Calculator",
    card:"Dose, ratio, water — dial in a brew without a recipe card.",
    lede:"Start with the coffee you have, choose a ratio and get the water weight. A 1:16 ratio is the usual starting point for pour-over and drip.",
    related:["cups-to-grams","butter","pizza-dough"],
    ui(){
      return `
      <section class="calc" aria-label="Coffee ratio calculator">
        <div class="calc-top"><p class="calc-label">CALCULATE</p></div>
        <div class="calc-grid">
          <label class="field"><span class="field-label">Coffee dose (g)</span><input id="cf-dose" type="number" inputmode="decimal" value="18" step="1" min="0"></label>
          <label class="field"><span class="field-label">Ratio (coffee : water)</span>
            <select id="cf-ratio">
              <option value="15">1 : 15 — strong</option>
              <option value="16" selected>1 : 16 — balanced</option>
              <option value="17">1 : 17 — light</option>
              <option value="18">1 : 18 — tea-like</option>
            </select>
          </label>
        </div>
        <div class="result">
          <div class="stat"><p class="stat-label">Water</p><p class="stat-value"><span id="cf-water">288</span><small>g</small></p><p class="stat-sub" id="cf-sub">About 1.2 cups (240 ml each).</p></div>
          <div class="stat"><p class="stat-label">Ratio</p><p class="stat-value">1:<span id="cf-r">16</span></p><p class="stat-sub"><span id="cf-oz">9.7</span> fl oz</p></div>
        </div>
        <p class="calc-note">1 ml of water weighs about 1 g. If you have no scale, a level tablespoon holds roughly 5 g of ground coffee.</p>
        <div class="calc-actions"><button class="btn btn-ghost" type="button" id="cf-copy">Copy result</button></div>
      </section>`;
    },
    mount(root){
      const dose=root.querySelector("#cf-dose"), ratio=root.querySelector("#cf-ratio");
      const water=root.querySelector("#cf-water"), sub=root.querySelector("#cf-sub"), r=root.querySelector("#cf-r"), oz=root.querySelector("#cf-oz");
      function calc(){
        const d=num(dose.value), rr=num(ratio.value);
        if(d<=0){ water.textContent="—"; sub.textContent="Enter a dose above zero."; return; }
        const w=d*rr;
        water.textContent=fmt(w); r.textContent=rr; oz.textContent=fmt(w/29.5735,1);
        sub.textContent = LANG==="zh" ? `约 ${fmt(w/240,1)} 杯（每杯 240 毫升）。` : `About ${fmt(w/240,1)} cups (240 ml each).`;
      }
      dose.addEventListener("input",calc);
      ratio.addEventListener("change",calc);
      wireCopy(root.querySelector("#cf-copy"), ()=>`${dose.value} g coffee + ${water.textContent} g water (1:${r.textContent})`);
      calc();
    }
  },
  {
    slug:"pizza-dough",
    cat:"Dough",
    title:"Pizza Dough Calculator",
    card:"Baker's percentages by weight, for any number of pies.",
    lede:"Enter how many pizzas and how wide, and get a full dough formula by weight — flour, water, salt and instant yeast — using baker's percentages.",
    related:["oven-temperature","cups-to-grams","pan-size"],
    ui(){
      return `
      <section class="calc" aria-label="Pizza dough calculator">
        <div class="calc-top"><p class="calc-label">BUILD A FORMULA</p></div>
        <div class="calc-grid">
          <label class="field"><span class="field-label">Number of pizzas</span><input id="pz-count" type="number" inputmode="numeric" value="2" step="1" min="1"></label>
          <label class="field"><span class="field-label">Diameter (in)</span><input id="pz-size" type="number" inputmode="decimal" value="12" step="1" min="4"></label>
          <label class="field"><span class="field-label">Thickness</span>
            <select id="pz-thick"><option value="2.1">Thin crust</option><option value="2.6" selected>Regular</option><option value="3.2">Thick / pan</option></select>
          </label>
          <label class="field"><span class="field-label">Bowl size hint</span><input value="2× dough volume" disabled style="opacity:.55"></label>
        </div>
        <div class="result result-3">
          <div class="stat"><p class="stat-label">Total dough</p><p class="stat-value"><span id="pz-total">588</span><small>g</small></p><p class="stat-sub" id="pz-ball">294 g per ball</p></div>
          <div class="stat"><p class="stat-label">Flour (100%)</p><p class="stat-value"><span id="pz-flour">357</span><small>g</small></p><p class="stat-sub">Bread or 00 flour</p></div>
          <div class="stat"><p class="stat-label">Water (62%)</p><p class="stat-value"><span id="pz-water">222</span><small>g</small></p><p class="stat-sub">Room temperature</p></div>
        </div>
        <div class="calc-grid" style="border-top:1px solid var(--hair)">
          <label class="field"><span class="field-label">Salt (2%)</span><input id="pz-salt" value="7" disabled style="opacity:.75"></label>
          <label class="field"><span class="field-label">Instant yeast (0.5%)</span><input id="pz-yeast" value="1.8" disabled style="opacity:.75"></label>
        </div>
        <p class="calc-note">Mix, rest 20 minutes, then knead. Cold-ferment the balls for 24–48 hours for better flavor and an easier stretch.</p>
        <div class="calc-actions"><button class="btn btn-ghost" type="button" id="pz-copy">Copy formula</button></div>
      </section>`;
    },
    mount(root){
      const count=root.querySelector("#pz-count"), size=root.querySelector("#pz-size"), thick=root.querySelector("#pz-thick");
      const total=root.querySelector("#pz-total"), ball=root.querySelector("#pz-ball"), flour=root.querySelector("#pz-flour"),
            water=root.querySelector("#pz-water"), salt=root.querySelector("#pz-salt"), yeast=root.querySelector("#pz-yeast");
      function calc(){
        const n=Math.max(1,Math.round(num(count.value))), d=num(size.value);
        if(d<4){ total.textContent="—"; return; }
        const area=Math.PI*Math.pow(d/2,2), ballW=area*num(thick.value), tot=ballW*n, f=tot/1.645;
        total.textContent=fmt(tot); ball.textContent=`${fmt(ballW)} g per ball`;
        flour.textContent=fmt(f); water.textContent=fmt(f*0.62);
        salt.value=fmt(f*0.02,1); yeast.value=fmt(f*0.005,1);
      }
      [count,size,thick].forEach(el=>el.addEventListener("input",calc));
      thick.addEventListener("change",calc);
      wireCopy(root.querySelector("#pz-copy"), ()=>`${count.value} × ${size.value}in pizza: ${flour.textContent} g flour, ${water.textContent} g water, ${salt.value} g salt, ${yeast.value} g yeast`);
      calc();
    }
  },
  {
    slug:"liquid",
    cat:"Weight",
    title:"Liquid Volume Converter",
    card:"Cups, millilitres, fluid ounces, tablespoons, teaspoons.",
    lede:"Liquid measurements are the easiest to convert, but US and metric cups differ. This tool uses the US customary cup (236.6 ml).",
    related:["cups-to-grams","butter","rice-ratio"],
    ui(){
      return `
      <section class="calc" aria-label="Liquid volume converter">
        <div class="calc-top"><p class="calc-label">CONVERT</p></div>
        <div class="calc-grid">
          <label class="field"><span class="field-label">Amount</span><input id="lq-amt" type="number" inputmode="decimal" value="1" step="0.25" min="0"></label>
          <label class="field"><span class="field-label">Unit</span>
            <select id="lq-unit">
              <option value="cup">Cups (US)</option>
              <option value="ml">Millilitres</option>
              <option value="floz">Fluid ounces (US)</option>
              <option value="tbsp">Tablespoons</option>
              <option value="tsp">Teaspoons</option>
            </select>
          </label>
        </div>
        <div class="result result-5">
          <div class="stat"><p class="stat-label">Cups</p><p class="stat-value"><span id="lq-cup">1</span></p></div>
          <div class="stat"><p class="stat-label">Millilitres</p><p class="stat-value"><span id="lq-ml">237</span></p></div>
          <div class="stat"><p class="stat-label">Fluid ounces</p><p class="stat-value"><span id="lq-floz">8</span></p></div>
          <div class="stat"><p class="stat-label">Tablespoons</p><p class="stat-value"><span id="lq-tbsp">16</span></p></div>
          <div class="stat"><p class="stat-label">Teaspoons</p><p class="stat-value"><span id="lq-tsp">48</span></p></div>
        </div>
        <p class="calc-note">A US cup is 236.6 ml; a metric cup is 250 ml. Recipes written in cups are almost always US cups.</p>
        <div class="calc-actions"><button class="btn btn-ghost" type="button" id="lq-copy">Copy result</button></div>
      </section>`;
    },
    mount(root){
      const amt=root.querySelector("#lq-amt"), unit=root.querySelector("#lq-unit");
      const out={cup:root.querySelector("#lq-cup"),ml:root.querySelector("#lq-ml"),floz:root.querySelector("#lq-floz"),tbsp:root.querySelector("#lq-tbsp"),tsp:root.querySelector("#lq-tsp")};
      if(isMetric()){ unit.value="ml"; amt.value="250"; }
      function calc(){
        const v=num(amt.value); let ml=0;
        switch(unit.value){
          case "cup": ml=v*236.588; break;
          case "ml": ml=v; break;
          case "floz": ml=v*29.5735; break;
          case "tbsp": ml=v*14.7868; break;
          case "tsp": ml=v*4.92892; break;
        }
        out.ml.textContent=fmt(ml);
        out.cup.textContent=fmt(ml/236.588,2);
        out.floz.textContent=fmt(ml/29.5735,2);
        out.tbsp.textContent=fmt(ml/14.7868,2);
        out.tsp.textContent=fmt(ml/4.92892,2);
      }
      amt.addEventListener("input",calc);
      unit.addEventListener("change",calc);
      wireCopy(root.querySelector("#lq-copy"), ()=>`${amt.value} ${unit.value} = ${out.ml.textContent} ml (${out.cup.textContent} cups)`);
      calc();
    }
  },
  {
    slug:"rice-ratio",
    cat:"Dough",
    title:"Rice & Water Ratio Calculator",
    card:"Water volume for white, brown, jasmine and sushi rice.",
    lede:"Rice is cooked by volume more often than by weight. Pick the type, enter the dry rice volume, and get the water volume plus an approximate cooked yield.",
    related:["cups-to-grams","liquid","pizza-dough"],
    ui(){
      return `
      <section class="calc" aria-label="Rice ratio calculator">
        <div class="calc-top"><p class="calc-label">CALCULATE</p></div>
        <div class="calc-grid">
          <label class="field"><span class="field-label">Dry rice (cups)</span><input id="rc-cups" type="number" inputmode="decimal" value="1" step="0.25" min="0"></label>
          <label class="field"><span class="field-label">Rice type</span>
            <select id="rc-type">
              <option value="1.5" selected>White long-grain (1 : 1.5)</option>
              <option value="1.5">Jasmine (1 : 1.5)</option>
              <option value="1.5">Basmati (1 : 1.5)</option>
              <option value="1.25">Sushi / short-grain (1 : 1.25)</option>
              <option value="2">Brown rice (1 : 2)</option>
              <option value="2">Wild rice blend (1 : 2)</option>
            </select>
          </label>
        </div>
        <div class="result result-3">
          <div class="stat"><p class="stat-label">Water</p><p class="stat-value"><span id="rc-water">1.5</span><small>cups</small></p><p class="stat-sub" id="rc-ml">355 ml</p></div>
          <div class="stat"><p class="stat-label">Cooked yield</p><p class="stat-value"><span id="rc-yield">3</span><small>cups</small></p><p class="stat-sub">Approximate</p></div>
          <div class="stat"><p class="stat-label">Dry weight</p><p class="stat-value"><span id="rc-g">185</span><small>g</small></p><p class="stat-sub">At 185 g per cup</p></div>
        </div>
        <p class="calc-note">Rinse until the water is mostly clear, bring to a boil, then cover and simmer on low. Rest 10 minutes off the heat before fluffing.</p>
        <div class="calc-actions"><button class="btn btn-ghost" type="button" id="rc-copy">Copy result</button></div>
      </section>`;
    },
    mount(root){
      const cups=root.querySelector("#rc-cups"), type=root.querySelector("#rc-type");
      const water=root.querySelector("#rc-water"), ml=root.querySelector("#rc-ml"), yieldEl=root.querySelector("#rc-yield"), g=root.querySelector("#rc-g");
      function calc(){
        const c=num(cups.value), ratio=num(type.value);
        if(c<=0){ water.textContent="—"; ml.textContent=""; yieldEl.textContent="—"; g.textContent="—"; return; }
        const w=c*ratio;
        water.textContent=fmt(w,2); ml.textContent=`${fmt(w*236.588)} ml`;
        yieldEl.textContent=fmt(c*3,1); g.textContent=fmt(c*185);
      }
      cups.addEventListener("input",calc);
      type.addEventListener("change",calc);
      wireCopy(root.querySelector("#rc-copy"), ()=>`${cups.value} cup(s) dry rice + ${water.textContent} cup(s) water`);
      calc();
    }
  }
];

/* ============================================================
   Tool prose
   ============================================================ */
const TOOL_PROSE = {
  "air-fryer":`
    <h2>How the conversion works</h2>
    <ul>
      <li><b>Temperature:</b> air fryer setting = oven temperature − 25°F (15°C).</li>
      <li><b>Time:</b> air fryer time = oven time × 0.8. The reverse adds 25°F and divides by 0.8.</li>
      <li><b>Check early:</b> open the basket at about 80% of the converted time. Small appliances vary more than full ovens.</li>
    </ul>
    <h2>Good to know</h2>
    <ul>
      <li>Fan-assisted ovens already run cooler on the dial; if the recipe was written for a fan oven, use the oven temperature as-is and only cut the time.</li>
      <li>Cook in a single layer. Crowding turns roasting into steaming and breaks the timing rule.</li>
      <li>Breaded and cheese-topped food browns fast on top — cover with foil for the first half if needed.</li>
    </ul>
    <p>Related lesson: <a href="#/school/heat/oven-vs-air-fryer">Oven vs air fryer: the 25°F rule</a>.</p>`,
  "cups-to-grams":`
    <h2>How the conversion works</h2>
    <ul>
      <li><b>Formula:</b> grams = cups × grams per cup for that ingredient.</li>
      <li>Grams per cup is a density value measured for a standard US cup (240 ml).</li>
      <li>Reverse: cups = grams ÷ grams per cup.</li>
    </ul>
    <h2>Good to know</h2>
    <ul>
      <li>Spoon the flour into the cup and level it. Scooping compacts the flour and can add 15–20%.</li>
      <li>Brown sugar is measured packed unless a recipe says otherwise.</li>
      <li>For the most reliable baking, use a scale and follow weights when a recipe provides them.</li>
    </ul>
    <p>Related lesson: <a href="#/school/measure/weight-vs-volume">Why weight beats volume</a>.</p>`,
  "butter":`
    <h2>How the conversion works</h2>
    <ul>
      <li><b>Anchor:</b> 1 US stick = ½ cup = 8 tablespoons = 113 g = 4 oz.</li>
      <li>Everything is converted through grams: 1 cup = 227 g, 1 tbsp = 14.175 g, 1 oz = 28.35 g.</li>
    </ul>
    <h2>Good to know</h2>
    <ul>
      <li>A 250 g European block is slightly more than two US sticks (226 g).</li>
      <li>If a recipe calls for melted butter by volume, melt first, then measure.</li>
    </ul>`,
  "pan-size":`
    <h2>How the conversion works</h2>
    <ul>
      <li><b>Round:</b> area = π × (diameter ÷ 2)². <b>Square:</b> side × side. <b>Rectangle:</b> length × width.</li>
      <li><b>Multiplier:</b> new area ÷ original area. Multiply every ingredient by it.</li>
    </ul>
    <h2>Good to know</h2>
    <ul>
      <li>An 8-inch round is about 50 in²; an 8-inch square is 64 in² — the square holds 27% more.</li>
      <li>The math assumes both pans are the same depth. A much deeper pan needs a lower temperature and a longer bake.</li>
      <li>Do not use area math to swap a springform for a loose pan on water-bath bakes.</li>
    </ul>
    <p>Related lesson: <a href="#/school/pans/pan-area">Pan area math that matters</a>.</p>`,
  "oven-temperature":`
    <h2>How the conversion works</h2>
    <ul>
      <li><b>Fahrenheit:</b> F = C × 9/5 + 32. <b>Celsius:</b> C = (F − 32) × 5/9.</li>
      <li><b>Fan Celsius:</b> fan = C − 20 (the fan setting runs about 20°C cooler on the dial).</li>
      <li><b>Gas marks:</b> standard table from 1 (275°F) to 9 (475°F); the nearest mark is shown.</li>
    </ul>
    <h2>Good to know</h2>
    <ul>
      <li>Oven thermostats drift. For anything delicate, verify with an oven thermometer.</li>
      <li>Gas mark 4 is 350°F / 175°C — the most common baking setting.</li>
    </ul>`,
  "thawing-time":`
    <h2>How the conversion works</h2>
    <ul>
      <li><b>Refrigerator:</b> about 24 hours per 5 lb (4.8 hours per lb).</li>
      <li><b>Cold water:</b> about 30 minutes per lb, sealed, changing the water every 30 minutes.</li>
      <li><b>Microwave:</b> about 7 minutes per lb, then cook immediately.</li>
    </ul>
    <h2>Good to know</h2>
    <ul>
      <li>Never thaw meat on the counter. The outer layer enters the danger zone while the center is still frozen.</li>
      <li>Refrigerator-thawed meat keeps for about 1–2 days before cooking.</li>
    </ul>
    <p>Related lesson: <a href="#/school/safety/thaw-safely">Thawing: fridge, water, microwave</a>.</p>`,
  "coffee-ratio":`
    <h2>How the conversion works</h2>
    <ul>
      <li><b>Water:</b> grams = coffee dose × ratio.</li>
      <li>1:16 is the common starting point for drip and pour-over; 1:15 is stronger, 1:17 lighter.</li>
      <li>1 ml of water weighs about 1 g, so grams and millilitres are interchangeable here.</li>
    </ul>
    <h2>Good to know</h2>
    <ul>
      <li>Without a scale, a level tablespoon of ground coffee is roughly 5 g.</li>
      <li>Espresso uses a much tighter ratio (around 1:2); this calculator is for filter methods.</li>
    </ul>
    <p>Related lesson: <a href="#/school/coffee/coffee-ratio">Ratios and doses</a>.</p>`,
  "pizza-dough":`
    <h2>How the conversion works</h2>
    <ul>
      <li><b>Dough ball:</b> area × thickness factor. Thin 2.1, regular 2.6, thick 3.2 g per square inch.</li>
      <li><b>Total dough:</b> balls × ball weight.</li>
      <li><b>Baker's percentages:</b> flour 100%, water 62%, salt 2%, instant yeast 0.5% — total 164.5%, so flour = total ÷ 1.645.</li>
    </ul>
    <h2>Good to know</h2>
    <ul>
      <li>62% hydration is easy to stretch by hand. Raise it to 65% for a puffier rim, but expect a stickier dough.</li>
      <li>Cold-ferment the balls for 24–48 hours for better flavor.</li>
    </ul>`,
  "liquid":`
    <h2>How the conversion works</h2>
    <ul>
      <li>All values are converted through millilitres.</li>
      <li><b>US cup</b> = 236.588 ml; <b>fluid ounce</b> = 29.5735 ml; <b>tablespoon</b> = 14.7868 ml; <b>teaspoon</b> = 4.92892 ml.</li>
    </ul>
    <h2>Good to know</h2>
    <ul>
      <li>A metric cup is 250 ml, about 5.7% larger than a US cup.</li>
      <li>UK fluid ounces are 28.413 ml — different again. Recipes in cups are usually US.</li>
    </ul>`,
  "rice-ratio":`
    <h2>How the conversion works</h2>
    <ul>
      <li><b>Water volume:</b> dry rice volume × the type's ratio.</li>
      <li>White, jasmine and basmati use 1:1.5; sushi rice 1:1.25; brown and wild rice 1:2.</li>
      <li>Cooked yield is approximate: white rice roughly triples in volume.</li>
    </ul>
    <h2>Good to know</h2>
    <ul>
      <li>Rinse until the water is mostly clear to remove surface starch.</li>
      <li>Rest 10 minutes off the heat before fluffing; the steam finishes the grains.</li>
      <li>Brown rice benefits from a 30-minute soak before cooking.</li>
    </ul>`
};

/* ============================================================
   Locale state + Chinese edition
   ============================================================ */
const LOCALE_KEY = "ks_locale_v3";
const STATIC = !!(typeof window !== "undefined" && window.__STATIC__);
const BASE = (typeof window !== "undefined" && typeof window.__BASE__ === "string") ? window.__BASE__ : "";
const STATIC_PATH = (typeof window !== "undefined" && typeof window.__STATIC_PATH__ === "string") ? window.__STATIC_PATH__ : null;
let LANG = "en";
let REGION = "US";
try {
  const saved = JSON.parse(localStorage.getItem(LOCALE_KEY) || "{}");
  if (saved.lang === "zh") LANG = "zh";
  if (["US", "UK", "EU", "CN"].includes(saved.region)) REGION = saved.region;
} catch (e) {}
try {
  const qp = new URLSearchParams(location.search);
  const ql = qp.get("lang"), qr = qp.get("region");
  if (ql === "zh" || ql === "en") LANG = ql;
  if (["US", "UK", "EU", "CN"].includes(qr)) REGION = qr;
} catch (e) {}
function isMetric(){ return REGION !== "US"; }

const ZH = {
  modules: {
    measure: { title:"测量与换算", dek:"杯子不可靠，秤才可靠。把称重变成习惯，后面每一课都会更稳。", outcome:"把任何食谱换算成克，并按比例缩放而不破坏口感。" },
    heat: { title:"热源与烤箱", dek:"每台烤箱都会说谎。掌握三种加热方式和两个最常用的换算。", outcome:"在烤箱、热风与空气炸锅之间换算，不再靠猜。" },
    pans: { title:"烤盘与烘焙", dek:"面积决定面糊放不放得下，深度决定烤不烤得透。", outcome:"用面积计算换烤盘，并相应调整时间。" },
    dough: { title:"面团与面包", dek:"面粉、水、时间。三个变量能解释几乎所有的面团问题。", outcome:"看懂配方中的烘焙百分比，并敢调含水量。" },
    safety: { title:"食品安全", dek:"四个数字、两个习惯，覆盖几乎所有关键点。", outcome:"解冻、烹饪、复热都不再靠运气。" },
    coffee: { title:"咖啡与饮品", dek:"粉量、研磨、水。三个旋钮，按顺序调。", outcome:"冲出一杯可复现的咖啡，味道不对时知道该调哪个旋钮。" }
  },
  lessons: {
    "weight-vs-volume": { title:"为什么称重比量体积可靠", dek:"一杯面粉并不是固定重量。先看看误差能有多大。", practice:"用两种方法各称一杯面粉：直接从袋里舀，和用勺子舀入抹平。比较两个数字，差值就是你的误差预算。", body:`
      <h2>为什么重要</h2><p>美制一杯中筋面粉的重量大约在 110–150 克之间，取决于怎么装进杯子。对蛋糕的主料来说，这是 30% 的浮动，任何配方都吸收不了。</p><p>称重能消掉这个变量：面粉松、紧、受潮，一克还是一克。</p>
      <h2>做法</h2><ol><li>先把空碗放上秤，按归零。</li><li>按食谱的克数加料，不要用杯子从袋里舀进碗里。</li><li>液体用毫升或克，液体杯比干量杯稳定得多。</li></ol>
      <h2>常见错误</h2><ul><li>食谱没写“压实”却压实红糖。</li><li>在搅拌碗上方称量，倒多了收不回去。</li><li>以为所有食材的一杯都一样重。</li></ul>` },
    "use-a-scale": { title:"用秤而不拖慢速度", dek:"归零、加料、到位。三个动作，十秒钟。", practice:"把一份需要 2¼ 杯中筋面粉的食谱换算成克（按每杯 125 克），称出来，再回看你用杯子会差多少。", body:`
      <h2>为什么重要</h2><p>十五美元的厨房秤比抽屉里所有量杯都准。代价只是学一个三步流程。</p>
      <h2>做法</h2><ol><li>空碗放上秤，归零。</li><li>看显示屏，加到目标重量。</li><li>换食材时再归零，继续在同一个碗里叠。</li></ol><p>面粉、糖、黄油用 1 克精度；酵母和盐更需要 0.1 克精度，而不是更大的量程。</p>
      <h2>常见错误</h2><ul><li>忘了归零，把碗的重量算进面粉。</li><li>接近目标还倒得很快。</li><li>从不校准——一袋 500 克的糖就能做快速检查。</li></ul>` },
    "scale-a-recipe": { title:"放大或缩小食谱", dek:"先乘食材，再改烤盘和时钟——顺序不能反。", practice:"把一份 8×8 英寸布朗尼配方翻倍，在 9×13 烤盘和两个 8×8 烤盘之间做选择，先算好两种方案的面糊深度再开烤。", body:`
      <h2>为什么重要</h2><p>翻倍不是把所有数字翻倍。食材是线性的，烤盘不是，时间更不是。</p>
      <h2>做法</h2><ol><li>系数 = 新份数 ÷ 原份数。</li><li>所有食材都乘，包括盐和膨松剂。</li><li>选一个面糊深度相同的烤盘。面积随直径的平方增长，不是直径。</li><li>时间最后调，同温下大批量通常多 5–10%。</li></ol>
      <h2>常见错误</h2><ul><li>用直径翻倍的烤盘，面积会变成四倍。</li><li>深盘仍用原来的时间。</li><li>把“一小撮”调料也按精确比例放——要尝，不要算。</li></ul>` },
    "oven-heat": { title:"烤箱的热是怎么工作的", dek:"传导、对流、辐射——以及为什么旋钮只是一个平均值。", practice:"做面包测试：把切片面包单层放在中层，175°C 烤 6 分钟，拍照并标出先变深的角落。", body:`
      <h2>为什么重要</h2><p>烤箱不是恒定温度，而是围绕一个目标循环。加热管开开关关，靠门的位置总比后壁冷。旋钮是目标，不是实测。</p>
      <h2>做法</h2><ol><li>预热满 20 分钟，不是显示屏说的 8 分钟。</li><li>把烤箱温度计放在中层，和旋钮对比。</li><li>找热点：把面包片单层烤一次，看哪个角先上色。</li></ol><p>传导来自烤盘，对流来自流动的空气，辐射来自加热管。深色烤盘吸热快，浅色烤盘更温和。</p>
      <h2>常见错误</h2><ul><li>烤到一半就开门“看一眼”，温度可能掉 15°C。</li><li>相信二十年前的温控器。</li><li>两层同时烤却不中途换位。</li></ul>` },
    "oven-vs-air-fryer": { title:"烤箱与空气炸锅：降 15°C、减 20%", dek:"降一次温度，减一次时间，提前检查一次。", practice:"把一份 220°C、25 分钟的烤箱烤肉换算成空气炸锅设置，按换算时间的 80% 开始检查。", body:`
      <h2>为什么重要</h2><p>空气炸锅就是一个小型、强对流的烤箱。照搬烤箱数字会过火，减太多又会不熟。</p>
      <h2>做法</h2><ol><li>温度降 25°F（15°C）。</li><li>时间减 20%。</li><li>在新时间的 80% 处检查，之后只加不减。</li></ol><p>如果原配方本来就是热风烤箱，温度已经降过，只减时间。</p>
      <h2>常见错误</h2><ul><li>把炸篮塞满，食物在蒸而不是烤。</li><li>把三小时炖煮换算成空气炸锅。</li><li>以为每台空气炸锅的实际温度一样——第一批就是校准。</li></ul>` },
    "read-your-oven": { title:"看懂热风、燃气标记和热点", dek:"热风挡、燃气刻度、20°C 偏移，一次讲清。", practice:"找出 180°C、200°C、220°C 三个食谱的热风换算，写下你实际会设的旋钮温度。", body:`
      <h2>为什么重要</h2><p>食谱在不同国家之间旅行，旋钮刻度却不一样。热风烤箱的 180°C 不是普通烤箱的 180°C，燃气标记 4 也不是能心算出来的数字。</p>
      <h2>做法</h2><ol><li>热风：比普通食谱低约 20°C（35°F）。</li><li>燃气：用标准表，4 档 = 175°C，6 档 = 205°C。</li><li>热点：中途转盘，把最需要上色的放在后半区。</li></ol>
      <h2>常见错误</h2><ul><li>用算术换算燃气标记而不是查表。</li><li>烤蛋奶布丁还用热风且不降温。</li><li>以为最上层一定最热——通常是的，但加热管位置决定一切。</li></ul>` },
    "pan-area": { title:"真正有用的烤盘面积计算", dek:"一分钟学会 πr²，以及为什么 8 英寸圆模不等于 8 英寸方模。", practice:"算出 8 英寸圆、9 英寸圆、8 英寸方三个烤盘的面积，先排序再点开工具核对。", body:`
      <h2>为什么重要</h2><p>食谱是按烤盘的容量写的，容量从面积开始。两个宽度数字相同的烤盘，装的面糊可能差很多。</p>
      <h2>做法</h2><ol><li>圆：π×(直径÷2)²，8 英寸约 50 平方英寸。</li><li>方：边长×边长，8 英寸是 64。</li><li>矩形：长×宽，9×13 是 117。</li></ol><p>新面积 ÷ 原面积 = 食材倍率。尽量保持面糊深度不变。</p>
      <h2>常见错误</h2><ul><li>把直径和边长当成同一个量。</li><li>忽略深度，宽而浅的盘熟得更快也更干。</li><li>只知道宽度却按体积缩放。</li></ul>` },
    "swap-pans": { title:"换烤盘而不毁掉这一炉", dek:"先对面积，再保深度，最后才动时间。", practice:"把一份 9 英寸圆模配方改到 8 英寸方模，写下倍率、预期深度和时间调整。", body:`
      <h2>为什么重要</h2><p>换烤盘是几何题，后果是烘焙。面积对了面糊放得下，深度错了口感就变。</p>
      <h2>做法</h2><ol><li>算两个面积和倍率。</li><li>选面糊深度差不超过约 1 英寸的盘。</li><li>新盘更深就降温 10–15°F 并加时间。</li><li>更浅就提前检查，常常早 10 分钟。</li></ol>
      <h2>常见错误</h2><ul><li>水浴烘焙把活底模换成脱底模。</li><li>面糊超过模具三分之二。</li><li>同时换盘又换温度，最后不知道是谁造成的结果。</li></ul>` },
    "line-and-grease": { title:"铺纸与抹油：什么时候用哪种", dek:"油纸、黄油和面粉不是可以随便替换的。", practice:"给海绵蛋糕、布朗尼烤盘和酸面团面包各选一种处理方式，每个写一条理由。", body:`
      <h2>为什么重要</h2><p>铺法决定脱模是否干净，也决定边缘上色。选错的表现是蛋糕粘底或底部湿软。</p>
      <h2>做法</h2><ol><li>蛋糕：抹油、底部铺油纸、再抹油。</li><li>布朗尼和条状点心：油纸留边，提起来就脱模。</li><li>面包：抹油撒粉，高含水面团只抹油。</li><li>芝士蛋糕：底部铺纸，侧边轻抹。</li></ol>
      <h2>常见错误</h2><ul><li>无面粉蛋糕还撒面粉。</li><li>只抹中间，四角是干的。</li><li>热盘喷油，油在面糊到达前就烧焦了。</li></ul>` },
    "hydration": { title:"面粉、水和烘焙百分比", dek:"为什么每个面包配方都把面粉当作 100%。", practice:"为 500 克面粉写一份 65% 含水量的配方：水、盐、酵母各多少克；再改成 1000 克面粉，百分比不变。", body:`
      <h2>为什么重要</h2><p>烘焙百分比让配方可比较。面粉永远是 100%，其他配料都是面粉重量的一部分。65% 含水量就是每 100 克面粉配 65 克水，批量大小无关。</p>
      <h2>做法</h2><ol><li>称面粉，记为 100%。</li><li>设含水量：60% 偏硬，65% 容易操作且有开放气孔，75% 以上是湿面团。</li><li>盐 2%，即发干酵母 0.5–1%（当天发酵）。</li></ol><p>面粉蛋白也要看：面包粉 12–13% 吸水更多，中筋 10–11%，00 粉又是另一种表现。</p>
      <h2>常见错误</h2><ul><li>把含水量当成所有面粉通用的固定值。</li><li>不预留 5% 水来应对实际吸水。</li><li>减半时把盐的比例也减掉——盐的百分比不变。</li></ul>` },
    "knead-and-rest": { title:"揉面、静置与面筋", dek:"大部分工作由面团自己完成，你只需要等。", practice:"混一份 65% 含水量的面团，先静置 20 分钟再揉，记录你少加了多少面粉才让它动起来。", body:`
      <h2>为什么重要</h2><p>面筋靠两种力量形成：机械作用和时间。揉面是快路，静置是便宜的路。家庭烘焙者常揉过头、却静置不够。</p>
      <h2>做法</h2><ol><li>水解：先把面粉和水混合，静置 20–30 分钟，再加盐和酵母。</li><li>揉到面团光滑、能拉出薄窗。</li><li>主发酵期间每 30 分钟做一次拉伸折叠，而不是继续揉。</li></ol>
      <h2>常见错误</h2><ul><li>面团还粘手就不断加面粉，没给它水合时间。</li><li>湿面团在没撒粉的台面上揉到撕裂。</li><li>只看时间不看面团温度。</li></ul>` },
    "ferment": { title:"发酵：主发酵、最终发酵与冷藏", dek:"两次发酵，两个任务——冰箱是工具，不是拖延。", practice:"一份面团室温发酵，一份冷藏 24 小时，同样烘烤，比较外壳颜色和内部组织。", body:`
      <h2>为什么重要</h2><p>主发酵建立风味和结构，最终发酵决定组织。两者都在室温做，速度快、风味少；冷藏把两者分开。</p>
      <h2>做法</h2><ol><li>主发酵：室温发到体积增加 50–70%，每 30 分钟折叠一次。</li><li>整形后冷藏 12–48 小时，风味更好也更好烤。</li><li>最终发酵：室温发到手指轻按缓慢回弹。</li></ol>
      <h2>常见错误</h2><ul><li>只按时钟判断主发酵，面团温度才是变量。</li><li>冷藏取出不回复就直接烤。</li><li>最终发酵过头，面团塌了，烤出来是扁的。</li></ul>` },
    "thaw-safely": { title:"解冻：冷藏、冷水、微波炉", dek:"台面永远不是解冻方法。", practice:"计划一只 5 磅的鸡：写下放进冷藏的时间、最早可以烹饪的时间，再用解冻计算器核对。", body:`
      <h2>为什么重要</h2><p>室温解冻时，外层在危险温度带（4–60°C）待上几个小时，中心还是冰的。细菌在外层先长起来。</p>
      <h2>做法</h2><ol><li>冷藏：每 5 磅约 24 小时，放最下层。</li><li>冷水：密封、完全浸没，每磅约 30 分钟，每 30 分钟换水。</li><li>微波炉：每磅约 7 分钟，取出后立刻烹饪。</li></ol>
      <h2>常见错误</h2><ul><li>冷水解冻的肉不先做熟就复冻。</li><li>用热水加速，表面直接进危险带。</li><li>解冻后的禽肉在冰箱放一周——1–2 天内做掉。</li></ul>` },
    "doneness": { title:"用温度计代替猜测", dek:"颜色不是温度。记住四个数字。", practice:"用冰水校准温度计（0°C），然后在鸡腿的两个位置测温并比较。", body:`
      <h2>为什么重要</h2><p>切开肉看颜色既流失肉汁，也不能证明安全。一支即时读温度计三秒钟解决两个问题。</p>
      <h2>做法</h2><ol><li>禽肉（所有部位）74°C。</li><li>绞肉 71°C。</li><li>整块牛猪羊 63°C，静置 3 分钟。</li><li>鱼 63°C，或到能轻松剥落。</li></ol><p>测最厚处，避开骨头和脂肪，等读数稳定。</p>
      <h2>常见错误</h2><ul><li>测厚肉表面而不是中心。</li><li>以为余温一定会把中心补熟而不静置。</li><li>温度计从没在冰水里校准过。</li></ul>` },
    "cool-and-reheat": { title:"剩菜的冷却与复热", dek:"两小时内进冰箱，74°C 上桌。", practice:"检查冰箱：找出一盒超过四天的剩菜，和一盒用深锅直接冷却的。这周改掉这两个习惯。", body:`
      <h2>为什么重要</h2><p>家庭里大多数食源性疾病来自缓慢冷却和复热不均，而不是没煮熟。一个时钟加一支温度计就能解决。</p>
      <h2>做法</h2><ol><li>烹饪后两小时内装进浅容器。</li><li>开盖放冰箱直到冷透，再盖。</li><li>复热到 74°C，中途搅拌，避免冷点。</li><li>米饭只复热一次，且必须及时冷藏过。</li></ol>
      <h2>常见错误</h2><ul><li>一大锅热汤直接塞冰箱，中心降得太慢。</li><li>靠看和冒热气判断复热。</li><li>剩菜放超过 3–4 天。</li></ul>` },
    "coffee-ratio": { title:"咖啡的粉水比", dek:"一个数字就能把你带到一杯不错的咖啡。", practice:"用同一支豆子、同样的研磨，分别冲 1:15 和 1:17，各喝一口，写一句话描述差别。", body:`
      <h2>为什么重要</h2><p>浓度是比例，不是几勺。知道比例之后，换杯型就是算术，不是试错。</p>
      <h2>做法</h2><ol><li>称粉：一杯常见的单人份是 18 克。</li><li>从 1:16 开始，18 克粉配 288 克水。</li><li>按口味小步调，1:15 更浓，1:17 更淡。</li></ol><p>水的克数等于毫升数，把秤放在冲煮壶下就够了。</p>
      <h2>常见错误</h2><ul><li>同时改比例和研磨。</li><li>用体积勺量咖啡还假设每勺一样。</li><li>把意式浓缩的 1:2 和手冲比例混在一起。</li></ul>` },
    "grind-size": { title:"研磨度与萃取", dek:"酸通常是萃取不足，苦通常是萃取过度。", practice:"用同一支豆子，把研磨调细一格，粉量和水量不变，比较下水时间和味道。", body:`
      <h2>为什么重要</h2><p>研磨度控制水接触咖啡的速度。太粗，味道薄而酸；太细，苦而浑。</p>
      <h2>做法</h2><ol><li>按方法配研磨：法压粗、手冲中、意式中细。</li><li>每次只调一格，粉量和比例不变。</li><li>下水太快或堵住，先调研磨，再调比例。</li></ol>
      <h2>常见错误</h2><ul><li>买预磨咖啡还想调手冲。</li><li>为了“更多味道”磨得过细——萃取率和萃取量不是一回事。</li><li>换豆和调研磨同时做。</li></ul>` },
    "water-temp": { title:"水与温度", dek:"90–96°C，以及为什么你的水壶还没到。", practice:"用刚沸的水和离火 30 秒的水各冲一杯，其他条件不变，记录哪杯更苦。", body:`
      <h2>为什么重要</h2><p>水占一杯咖啡的 98% 以上。温度决定萃取速度，矿物质决定味道的清晰度。</p>
      <h2>做法</h2><ol><li>手冲和滴滤用 90–96°C。</li><li>水离火后等 30–45 秒再冲。</li><li>先用热水淋湿滤纸去纸味，再冲煮。</li></ol><p>硬水会压住风味，极软水会让咖啡显得平。自来水氯味重就用过滤水。</p>
      <h2>常见错误</h2><ul><li>滚水直接浇在浅烘豆上。</li><li>深烘和浅烘用同一个温度。</li><li>觉得“水就是水”而忽略它。</li></ul>` }
  },
  tools: {
    "air-fryer": { title:"空气炸锅时间与温度换算器", card:"把烤箱食谱变成空气炸锅设置，也能反着来。", lede:"空气炸锅比烤箱更热、更快。这个换算器同时调整温度和缩短时间，让烤箱食谱能直接进炸篮。", prose:`
      <h2>换算怎么算</h2><ul><li><b>温度：</b>空气炸锅 = 烤箱 − 25°F（15°C）。</li><li><b>时间：</b>空气炸锅 = 烤箱 × 0.8；反向则加 25°F、除以 0.8。</li><li><b>提前检查：</b>在换算时间的 80% 打开炸篮看一眼，小机器温差比大烤箱大。</li></ul>
      <h2>要知道</h2><ul><li>热风烤箱的旋钮温度本来就低；食谱写的是热风，温度照用，只减时间。</li><li>单层铺开。堆叠会把烤变成蒸，时间规则就失效了。</li><li>裹粉和芝士表面很容易上色，前一半时间可以盖锡纸。</li></ul><p>对应课程：<a href="#/school/heat/oven-vs-air-fryer">烤箱与空气炸锅：降 15°C、减 20%</a>。</p>` },
    "cups-to-grams": { title:"杯与克换算器", card:"一杯面粉不等于一杯糖，按食材换算。", lede:"杯量体积，克量重量。同一个杯子装面粉、糖和蜂蜜，重量完全不同。选食材，双向换算。", prose:`
      <h2>换算怎么算</h2><ul><li><b>公式：</b>克 = 杯 × 该食材每杯克数。</li><li>每杯克数是按美制一杯（240 毫升）测的密度值。</li><li>反向：杯 = 克 ÷ 每杯克数。</li></ul>
      <h2>要知道</h2><ul><li>用勺子把面粉舀进杯子再抹平。直接从袋里舀会压实，可能多出 15–20%。</li><li>红糖默认压实，除非食谱另说。</li><li>烘焙最稳的办法还是用秤，食谱给了克数就按克数来。</li></ul><p>对应课程：<a href="#/school/measure/weight-vs-volume">为什么称重比量体积可靠</a>。</p>` },
    "butter": { title:"黄油换算器", card:"条、杯、克、汤匙、盎司——一个输入，五个结果。", lede:"美制食谱按“条”数黄油，欧洲黄油按克称。一个输入就能在条、杯、克、汤匙和盎司之间换算。", prose:`
      <h2>换算怎么算</h2><ul><li><b>基准：</b>1 条 = ½ 杯 = 8 汤匙 = 113 克 = 4 盎司。</li><li>全部通过克换算：1 杯 = 227 克，1 汤匙 = 14.175 克，1 盎司 = 28.35 克。</li></ul>
      <h2>要知道</h2><ul><li>欧洲常见的 250 克块比两条美制黄油（226 克）略多。</li><li>食谱要求“融化黄油”并按体积计时，先融化再量。</li></ul>` },
    "pan-size": { title:"烤盘尺寸换算器", card:"换烤盘时按面积缩放食谱，而不是凭感觉。", lede:"两个烤盘装的面糊很少一样多。输入原烤盘和想用的烤盘，得到面积比，用来乘所有食材。", prose:`
      <h2>换算怎么算</h2><ul><li><b>圆：</b>面积 = π×(直径÷2)²。<b>方：</b>边长×边长。<b>矩形：</b>长×宽。</li><li><b>倍率：</b>新面积 ÷ 原面积。所有食材都乘这个数。</li></ul>
      <h2>要知道</h2><ul><li>8 英寸圆约 50 平方英寸，8 英寸方是 64——方盘多装 27%。</li><li>计算假设两个盘深度相同。深得多的盘要降温并延长时间。</li><li>水浴烘焙不要把活底模换成脱底模。</li></ul><p>对应课程：<a href="#/school/pans/pan-area">真正有用的烤盘面积计算</a>。</p>` },
    "oven-temperature": { title:"烤箱温度换算器", card:"华氏、摄氏、热风摄氏、燃气档，一屏看全。", lede:"烤箱旋钮彼此不一致，食谱也不一致。在华氏、摄氏、热风和燃气档之间任意方向换算。", prose:`
      <h2>换算怎么算</h2><ul><li><b>华氏：</b>F = C × 9/5 + 32。<b>摄氏：</b>C = (F − 32) × 5/9。</li><li><b>热风摄氏：</b>热风 = C − 20（热风挡的旋钮约低 20°C）。</li><li><b>燃气档：</b>标准表从 1 档（275°F）到 9 档（475°F），显示最接近的一档。</li></ul>
      <h2>要知道</h2><ul><li>烤箱温控会漂移。做精细烘焙时，用烤箱温度计核实。</li><li>燃气 4 档 = 350°F / 175°C，是最常用的烘焙温度。</li></ul>` },
    "thawing-time": { title:"解冻时间计算器", card:"冷藏、冷水或微波炉的安全解冻时间。", lede:"冷冻肉或禽肉多久能安全下锅？选方法和重量。这里用标准 USDA 速率，换算成好用的时间。", prose:`
      <h2>换算怎么算</h2><ul><li><b>冷藏：</b>每 5 磅约 24 小时（每磅 4.8 小时）。</li><li><b>冷水：</b>每磅约 30 分钟，密封、浸没，每 30 分钟换水。</li><li><b>微波炉：</b>每磅约 7 分钟，取出后立刻烹饪。</li></ul>
      <h2>要知道</h2><ul><li>绝不要在台面解冻。外层进危险带时，中心还是冰的。</li><li>冷藏解冻的肉在烹饪前大约还能放 1–2 天。</li></ul><p>对应课程：<a href="#/school/safety/thaw-safely">解冻：冷藏、冷水、微波炉</a>。</p>` },
    "coffee-ratio": { title:"咖啡粉水比计算器", card:"粉量、比例、水量——不用配方卡也能调出一杯。", lede:"从手头的咖啡粉开始，选一个比例，得到水量。手冲和滴滤通常从 1:16 起步。", prose:`
      <h2>换算怎么算</h2><ul><li><b>水量：</b>克 = 咖啡粉 × 比例。</li><li>1:16 是滴滤和手冲的常用起点；1:15 更浓，1:17 更淡。</li><li>1 毫升水约重 1 克，所以克和毫升在这里可以互换。</li></ul>
      <h2>要知道</h2><ul><li>没有秤时，一平汤匙咖啡粉大约 5 克。</li><li>意式浓缩的比例紧得多（约 1:2）；这个计算器只适用于过滤式。</li></ul><p>对应课程：<a href="#/school/coffee/coffee-ratio">咖啡的粉水比</a>。</p>` },
    "pizza-dough": { title:"披萨面团计算器", card:"按重量和烘焙百分比，算任意数量的饼。", lede:"输入几张饼、多大，得到完整的面团配方——面粉、水、盐、即发干酵母，全部按烘焙百分比。", prose:`
      <h2>换算怎么算</h2><ul><li><b>面团球：</b>面积 × 厚度系数。薄底 2.1、常规 2.6、厚底 3.2 克/平方英寸。</li><li><b>总面团：</b>球数 × 单球重量。</li><li><b>烘焙百分比：</b>面粉 100%、水 62%、盐 2%、即发干酵母 0.5%，合计 164.5%，所以面粉 = 总量 ÷ 1.645。</li></ul>
      <h2>要知道</h2><ul><li>62% 含水量适合手擀。想更蓬松可以到 65%，但面团会更粘。</li><li>面团球冷藏发酵 24–48 小时，风味更好。</li></ul>` },
    "liquid": { title:"液体体积换算器", card:"杯、毫升、液盎司、汤匙、茶匙。", lede:"液体最好换算，但美制和公制杯不一样。这个工具用美制杯（236.6 毫升）。", prose:`
      <h2>换算怎么算</h2><ul><li>所有单位先换成毫升。</li><li><b>美制杯</b> = 236.588 毫升；<b>液盎司</b> = 29.5735 毫升；<b>汤匙</b> = 14.7868 毫升；<b>茶匙</b> = 4.92892 毫升。</li></ul>
      <h2>要知道</h2><ul><li>公制杯是 250 毫升，比美制杯大约 5.7%。</li><li>英制液盎司是 28.413 毫升，又不一样。食谱写“杯”通常指美制。</li></ul>` },
    "rice-ratio": { title:"米水比例计算器", card:"白米、糙米、茉莉香米、寿司米，各要多少水。", lede:"煮饭常按体积而不是重量。选米种，输入生米体积，得到水量和大致熟饭产量。", prose:`
      <h2>换算怎么算</h2><ul><li><b>水量：</b>生米体积 × 该米种的比例。</li><li>白米、茉莉、印度香米 1:1.5；寿司米 1:1.25；糙米和野米 1:2。</li><li>熟饭产量是估算：白米大约膨胀到三倍体积。</li></ul>
      <h2>要知道</h2><ul><li>洗米到水基本清澈，去掉表面淀粉。</li><li>关火后焖 10 分钟再翻松，蒸汽会把米粒收完。</li><li>糙米煮前泡 30 分钟更好。</li></ul>` }
  },
  refs: {
    "grams-per-cup": { title:"每杯克数表", dek:"十四种常见食材，一杯的重量。", intro:"杯是体积，重量取决于食材。下表按平平一杯、用勺子舀入而不是直接舀取计算。", notes:"美制一杯 = 240 毫升。表里没有的食材，可以用杯与克换算器，输入你了解的密度。", headers:["食材","每杯克数"] },
    "oven-temperatures": { title:"烤箱温度表", dek:"华氏、摄氏、燃气档和热风温度，一张表。", intro:"燃气档是刻度，不是温度。按档位查对应行；热风烤箱再减 20°C。", notes:"多数食谱书会四舍五入到这些档位。烤箱温度计是唯一可靠的核实方式。", headers:["燃气档","°F","°C","热风 °C"] },
    "butter-measurements": { title:"黄油计量表", dek:"条、杯、克、汤匙和盎司。", intro:"一条美制黄油是基准：113 克、½ 杯、8 汤匙、4 盎司。其他都从这里推。", notes:"欧洲黄油块通常是 250 克，比两条美制黄油略多。融化黄油请在融化后量。", headers:["黄油用量","克","汤匙","盎司"] },
    "pan-sizes": { title:"常见烤盘尺寸与面积", dek:"常用烤盘的平方英寸面积。", intro:"面积决定食谱放不放得下，深度决定怎么烤。下表按各类烤盘的标准深度计算。", notes:"用新面积除以原面积得到倍率。面糊深度差控制在约 1 英寸以内。", headers:["烤盘","面积（平方英寸）","面积（平方厘米）","常见用途"] },
    "meat-doneness": { title:"肉类熟度温度", dek:"安全中心温度，华氏和摄氏。", intro:"以下为 USDA 最低安全温度。测最厚处，避开骨头，等读数稳定。", notes:"余温会继续加热。整块肉如果打算静置，可以提前 3–5°F 出锅。", headers:["食物","°F","°C","静置"] },
    "coffee-ratios": { title:"咖啡比例表", dek:"常见过滤式比例的粉量和水量。", intro:"过滤式咖啡按重量计。下表假设中研磨、90–96°C 冲煮。", notes:"意式浓缩比例紧得多，约 1:2。本表适用于滴滤、手冲和法压。", headers:["比例","18 克咖啡","水","风格"] }
  },
  pages: {
    about: `
      <div class="wrap">
        <p class="crumbs"><a href="#/">Home</a><span>/</span>About</p>
        <p class="kicker">关于</p>
        <h1 class="page-h1">一个只教一件事的小学校。</h1>
        <p class="lede">厨房学校是一个英文优先的教学站：十八节短课、十个计算器、六张速查表，无需注册。</p>
        <section class="prose">
          <h2>这是什么</h2><p>厨房里大多数错误是算术或习惯，不是天赋。课程覆盖六块：测量、热源、烤盘、面团、食品安全和咖啡。每节课最后都有一个小练习。</p>
          <h2>怎么建的</h2><p>一个静态站点。没有框架、没有数据库、没有账号。所有计算都在你的浏览器里完成，所以打开很快，打开一次后离线也能用。</p>
          <h2>靠什么维持</h2><p>站点免费阅读。开启展示广告后，广告会明确标注，并远离计算器。没有付费墙、没有账号，这个版本也没有联盟链接。</p>
          <h2>边界</h2><p>这些是估算和标准参考，不是实验室测量。烤箱、空气炸锅和烤盘都有差异。安全数据遵循 USDA，但最终仍以你自己的冰箱和温度计为准。</p>
        </section>
      </div>`,
    privacy: `
      <div class="wrap">
        <p class="crumbs"><a href="#/">Home</a><span>/</span>Privacy</p>
        <p class="kicker">隐私</p>
        <h1 class="page-h1">不收集，也不出售。</h1>
        <p class="lede">一个静态站点。计算和你输入的数字都留在浏览器里。</p>
        <section class="prose">
          <h2>我们收集什么</h2><p>没有账号、没有邮箱收集、没有分析脚本。唯一保存的是一项本地偏好：你选择的语言和地区，存在浏览器里，下次打开还能记住。</p>
          <h2>广告</h2><p>这个版本没有运行任何广告代码。如果以后开启展示广告，Google 及其合作方可能会设置 Cookie 并使用设备标识；届时会在任何广告代码运行前提供同意横幅和完整的广告说明。</p>
          <h2>你的输入</h2><p>你输入的数字只用于在设备上计算一个结果，不会被传输、记录或保存。</p>
          <h2>变更</h2><p>如果政策变化，本页底部的日期会一起更新。最后更新：2026 年 11 月。</p>
        </section>
      </div>`
  }
};

const ZH_UI = {
  "School":"课程", "Toolbox":"工具箱", "Charts":"速查表", "Reference":"参考", "About":"关于", "Privacy":"隐私", "Course":"课程", "Site":"站点", "Home":"首页", "Chart":"图表", "Tool":"工具",
  "Language":"语言", "Region":"地区", "United States":"美国", "United Kingdom":"英国", "Europe":"欧洲",
  "US units · °F, cups, lb":"美制 · °F、杯、磅", "Metric · °C, ml, lb":"公制 · °C、毫升、磅", "Metric · °C, ml, kg":"公制 · °C、毫升、千克",
  "Kitchen School · English-first · no account":"厨房学校 · 策略丰富 · 无需注册",
  "Learn the kitchen, then stop guessing.":"学会厨房，别再靠猜。",
  "Six modules, eighteen short lessons, ten calculators and six reference charts. Read one lesson, practise it once, then use the tool.":"六个模块、十八节短课、十个计算器、六张速查表。读一课，练一次，再用工具。",
  "Start the course":"开始课程", "modules":"个模块", "lessons":"节课", "tools":"个工具", "charts":"张表", "sign-ups":"注册",
  "The curriculum":"课程目录", "Full course →":"完整课程 →", "The toolbox":"工具箱", "All tools →":"全部工具 →",
  "Reference charts":"速查表", "All charts →":"全部速查表 →", "How to use this site":"怎么用这个站",
  "01 — READ":"01 — 读", "02 — PRACTISE":"02 — 练", "03 — USE":"03 — 用", "04 — CHECK":"04 — 查",
  "One lesson at a time":"一次只读一课",
  "Each lesson takes four to six minutes and ends with a small practice task.":"每课四到六分钟，最后有一个小练习。",
  "Do it once":"亲手做一次",
  "Weigh one cup of flour. Run the bread test. Temp a chicken thigh. The habit is the point.":"称一杯面粉，做一次面包测试，测一次鸡腿中心温度。习惯才是重点。",
  "Then use the tool":"再用工具",
  "Every lesson links to the calculator or chart that does the arithmetic for you.":"每节课都链到对应的计算器或速查表，算术交给它。",
  "Verify with a chart":"用速查表核对",
  "The six reference pages are printable and kept deliberately short.":"六张速查表都可以打印，刻意保持简短。",
  "Course · 06 modules · 18 lessons":"课程 · 06 个模块 · 18 节课",
  "The whole course, in order.":"完整课程，按顺序来。",
  "Work top to bottom, or jump to the module you need. Every lesson is short, ends with a practice task, and links to the tool that does the math.":"从上往下读，或直接跳到需要的模块。每课都短，都以练习收尾，并链到负责算术的工具。",
  "Every calculator on the site.":"站上所有计算器。",
  "One page per job. Each tool runs entirely in the browser and shows the formula behind the result.":"一个工具一个页面。每个工具都在浏览器里运行，并给出结果背后的公式。",
  "Toolbox · 10 tools":"工具箱 · 10 个工具",
  "The numbers, on one page each.":"数字都收在一页里。",
  "Short tables meant to be checked mid-recipe, not studied. Every chart links to the calculator that goes with it.":"短表，是做饭途中查的，不是拿来背的。每张表都链到配套计算器。",
  "Reference · 06 charts":"速查表 · 06 张表",
  "Reference · 06 charts":"速查表 · 06 张表",
  "Printable chart":"可打印表",
  "Practice":"练习", "Related tools":"相关工具", "Tools for this module":"本模块的工具", "Tools for this lesson":"本课的工具", "Use the tool":"用这个工具",
  "← All modules":"← 全部模块", "← All tools":"← 全部工具", "← All charts":"← 全部速查表", "All modules":"全部模块",
  "← Previous":"← 上一课", "Next →":"下一课 →", "← Back":"← 返回", "Finish →":"完成 →",
  "This page is not here.":"这个页面不在这里。",
  "The link may be old, or the page may have moved. Everything the site offers is listed below.":"链接可能过期，或页面搬走了。站上的全部内容都在下面。",
  "The course":"课程",
  "A short curriculum for the kitchen: measuring, heat, pans, dough, food safety and coffee. Ten calculators, six reference charts. English-first, ad-supported, no accounts.":"一份厨房短课程：测量、热源、烤盘、面团、食品安全和咖啡。十个计算器、六张速查表。英文优先，靠广告维持，无需账号。",
  "© 2026 Kitchen School · Static site, no tracking.":"© 2026 厨房学校 · 静态站点，不追踪。",
  "ADVERTISEMENT":"广告", "Responsive display slot · 970 × 90":"自适应广告位 · 970 × 90",
  "CONVERT":"换算", "CALCULATE":"计算", "ESTIMATE":"估算", "BUILD A FORMULA":"生成配方", "PAN A → PAN B":"烤盘 A → 烤盘 B",
  "Oven → Air fryer":"烤箱 → 空气炸锅", "Air fryer → Oven":"空气炸锅 → 烤箱", "Cups → grams":"杯 → 克", "Grams → cups":"克 → 杯",
  "Amount":"数量", "Unit":"单位", "Ingredient":"食材", "Temperature":"温度", "Time":"时间", "Method":"方法", "Weight":"重量", "Reference":"参考", "Water":"水", "Ratio":"比例",
  "Oven temperature":"烤箱温度", "Oven time (minutes)":"烤箱时间（分钟）", "Amount (cups)":"数量（杯）", "Amount (grams)":"数量（克）",
  "Copy result":"复制结果", "Copy formula":"复制配方", "g / cup":"克 / 杯", "US cup = 240 ml":"美制一杯 = 240 毫升",
  "Spoon the flour into the cup and level it. Scooping straight from the bag compacts it and can add 15–20%.":"用勺子把面粉舀进杯子再抹平。直接从袋里舀会压实，可能多出 15–20%。",
  "For melted butter, measure after melting if the recipe specifies melted — volume changes slightly.":"食谱要求融化黄油时，请在融化后量——体积会略有变化。",
  "Sticks":"条", "Cups":"杯", "Grams":"克", "Tablespoons":"汤匙", "Ounces":"盎司", "Millilitres":"毫升", "Fluid ounces":"液盎司", "Teaspoons":"茶匙",
  "Original pan shape":"原烤盘形状", "New pan shape":"新烤盘形状", "Round":"圆形", "Square":"方形", "Rectangle":"矩形",
  "Diameter (in)":"直径（英寸）", "Side (in)":"边长（英寸）", "Length (in)":"长（英寸）", "Width (in)":"宽（英寸）",
  "Multiply ingredients by":"食材乘以", "What this means":"这意味着", "Same area — no change needed.":"面积相同，不需要调整。",
  "Assumes both pans are the same depth.":"假设两个烤盘深度相同。",
  "Keep the batter depth close to the original. A much deeper pan needs a longer bake at a lower temperature.":"面糊深度尽量接近原配方。深得多的烤盘需要更低温度、更长时间。",
  "Fahrenheit":"华氏", "Celsius":"摄氏", "Gas mark":"燃气档", "Fan °C":"热风 °C",
  "Fan ovens usually run 20°C (35°F) hotter than the dial suggests. For delicate bakes, check with an oven thermometer.":"热风烤箱通常比旋钮显示高 20°C（35°F）。精细烘焙请用烤箱温度计核实。",
  "Refrigerator":"冷藏室", "Cold water":"冷水", "Microwave":"微波炉", "Estimated time":"预计时间", "Rule of thumb":"经验规则", "24 hr per 5 lb":"每 5 磅 24 小时", "Refrigerator method":"冷藏法",
  "Keep it on the lowest shelf and cook within 2 days of thawing.":"放最下层，解冻后 2 天内做熟。",
  "Coffee dose (g)":"咖啡粉（克）", "Ratio (coffee : water)":"比例（粉 : 水）",
  "1 : 15 — strong":"1 : 15 — 浓", "1 : 16 — balanced":"1 : 16 — 均衡", "1 : 17 — light":"1 : 17 — 淡", "1 : 18 — tea-like":"1 : 18 — 像茶",
  "1 ml of water weighs about 1 g. If you have no scale, a level tablespoon holds roughly 5 g of ground coffee.":"1 毫升水约重 1 克。没有秤时，一平汤匙咖啡粉大约 5 克。",
  "Number of pizzas":"披萨数量", "Thickness":"厚度", "Thin crust":"薄底", "Regular":"常规", "Thick / pan":"厚底 / 烤盘", "Bowl size hint":"容器容积参考", "2× dough volume":"面团体积的 2 倍",
  "Total dough":"面团总量", "Flour (100%)":"面粉（100%）", "Water (62%)":"水（62%）", "Salt (2%)":"盐（2%）", "Instant yeast (0.5%)":"即发干酵母（0.5%）", "Bread or 00 flour":"面包粉或 00 粉", "Room temperature":"室温",
  "Mix, rest 20 minutes, then knead. Cold-ferment the balls for 24–48 hours for better flavor and an easier stretch.":"混合，静置 20 分钟再揉。面团球冷藏发酵 24–48 小时，风味更好也更好擀。",
  "Dry rice (cups)":"生米（杯）", "Rice type":"米的种类", "Cooked yield":"熟饭产量", "Dry weight":"生米重量", "Approximate":"约", "At 185 g per cup":"按每杯 185 克",
  "White long-grain (1 : 1.5)":"长粒白米（1 : 1.5）", "Jasmine (1 : 1.5)":"茉莉香米（1 : 1.5）", "Basmati (1 : 1.5)":"印度香米（1 : 1.5）",
  "Sushi / short-grain (1 : 1.25)":"寿司米 / 短粒米（1 : 1.25）", "Brown rice (1 : 2)":"糙米（1 : 2）", "Wild rice blend (1 : 2)":"野米混合（1 : 2）",
  "Rinse until the water is mostly clear, bring to a boil, then cover and simmer on low. Rest 10 minutes off the heat before fluffing.":"洗到水基本清澈，煮开，转小火加盖。关火后焖 10 分钟再翻松。",
  "Cups (US)":"杯（美制）",
  "A US cup is 236.6 ml; a metric cup is 250 ml. Recipes written in cups are almost always US cups.":"美制一杯是 236.6 毫升，公制杯是 250 毫升。食谱里的“杯”几乎都是美制。",
  "Butter":"黄油", "Milk":"牛奶", "Water":"水", "Cocoa powder":"可可粉", "Rolled oats":"燕麦片", "Honey":"蜂蜜", "Table salt":"食盐",
  "All-purpose flour":"中筋面粉", "Bread flour":"面包粉", "Whole-wheat flour":"全麦粉", "Granulated sugar":"白砂糖", "Brown sugar, packed":"红糖（压实）", "Powdered sugar":"糖粉", "Uncooked white rice":"生白米",
  "6-inch round":"6 英寸圆模", "8-inch round":"8 英寸圆模", "9-inch round":"9 英寸圆模", "8-inch square":"8 英寸方模", "9-inch square":"9 英寸方模", "9×13 inch":"9×13 英寸", "8×8 inch":"8×8 英寸",
  "Small cake":"小蛋糕", "Layer cake":"分层蛋糕", "Layer cake, tart":"分层蛋糕、塔", "Brownies, cake":"布朗尼、蛋糕", "Sheet cake, roast":"烤盘蛋糕、烤肉",
  "Poultry (all parts)":"禽肉（所有部位）", "Ground meat":"绞肉", "Whole beef / pork / lamb":"整块牛/猪/羊", "Fish":"鱼", "Leftovers (reheat)":"剩菜（复热）",
  "None":"无需", "3 minutes":"3 分钟", "Strong":"浓", "Balanced":"均衡", "Light":"淡", "Tea-like":"像茶",
  "Ingredient":"食材", "Grams per cup":"每杯克数", "Butter amount":"黄油用量", "Pan":"烤盘", "Area (in²)":"面积（平方英寸）", "Area (cm²)":"面积（平方厘米）", "Typical use":"常见用途", "Food":"食物", "Rest":"静置", "18 g coffee":"18 克咖啡", "Style":"风格",
  "Heat":"加热", "Weight":"重量", "Pans":"烤盘", "Dough":"面团", "Safety":"食品安全", "Brew":"咖啡"
};

function zhOf(group, slug, field, fallback){
  if(LANG !== "zh") return fallback;
  const g = ZH[group] && ZH[group][slug];
  return (g && g[field]) ? g[field] : fallback;
}
function tn(name){
  if(LANG !== "zh") return name;
  return ZH_UI[name] || name;
}
function saveLocale(){
  try { localStorage.setItem(LOCALE_KEY, JSON.stringify({lang:LANG, region:REGION})); } catch(e) {}
}

const ZH_RULES = [
  [/^MODULE (\d+)$/, (m,p1)=>`模块 ${p1}`],
  [/^Module (\d+)$/, (m,p1)=>`模块 ${p1}`],
  [/^Module (\d+) · (\d+) lessons$/, (m,p1,p2)=>`模块 ${p1} · ${p2} 节课`],
  [/^MODULE (\d+) · LESSON (\d+)$/, (m,p1,p2)=>`模块 ${p1} · 第 ${p2} 课`],
  [/^Lesson (\d+)$/, (m,p1)=>`第 ${p1} 课`],
  [/^(\d+) min read · Practice included$/, (m,p1)=>`${p1} 分钟 · 含练习`],
  [/^(\d+) min$/, (m,p1)=>`${p1} 分钟`],
  [/^(\d+) lessons →$/, (m,p1)=>`${p1} 节课 →`],
  [/^By the end: (.+)$/, (m,p1)=>`学完你会：${p1}`],
  [/^(.+) · Tool$/, (m,p1)=>`${ZH_UI[p1]||p1} · 工具`]
];

function translateDOM(root){
  if(LANG !== "zh" || !root) return;
  const walker=document.createTreeWalker(root, NodeFilter.SHOW_TEXT, null);
  const nodes=[]; while(walker.nextNode()) nodes.push(walker.currentNode);
  nodes.forEach(n=>{
    const raw=n.nodeValue; const key=raw.trim();
    if(!key) return;
    let out=ZH_UI[key];
    if(!out){
      for(const [re,fn] of ZH_RULES){ if(re.test(key)){ out=key.replace(re,fn); break; } }
    }
    if(out) n.nodeValue=raw.replace(key,out);
  });
  root.querySelectorAll("[placeholder],[aria-label],[title]").forEach(el=>{
    ["placeholder","aria-label","title"].forEach(attr=>{
      const v=el.getAttribute(attr);
      if(v && ZH_UI[v.trim()]) el.setAttribute(attr, ZH_UI[v.trim()]);
    });
  });
}

function syncLocale(){
  const label=document.getElementById("locale-label");
  if(label) label.textContent=(LANG==="zh" ? "中文" : "EN") + " · " + REGION;
  document.documentElement.lang = LANG==="zh" ? "zh" : "en";
  document.querySelectorAll("[data-lang]").forEach(b=>b.classList.toggle("is-on", b.dataset.lang===LANG));
  document.querySelectorAll("[data-region]").forEach(b=>b.classList.toggle("is-on", b.dataset.region===REGION));
}

function initLocale(){
  const btn=document.getElementById("locale-btn");
  const panel=document.getElementById("locale-panel");
  if(!btn || !panel) return;
  btn.addEventListener("click", e=>{
    e.stopPropagation();
    const willOpen=panel.hidden;
    panel.hidden=!willOpen;
    btn.setAttribute("aria-expanded", String(willOpen));
  });
  document.addEventListener("click", e=>{
    if(!panel.hidden && !panel.contains(e.target) && !btn.contains(e.target)){
      panel.hidden=true;
      btn.setAttribute("aria-expanded","false");
    }
  });
  panel.querySelectorAll("[data-lang]").forEach(b=>b.addEventListener("click",()=>{
    LANG=b.dataset.lang; saveLocale(); panel.hidden=true;
    btn.setAttribute("aria-expanded","false"); syncLocale(); render();
  }));
  panel.querySelectorAll("[data-region]").forEach(b=>b.addEventListener("click",()=>{
    REGION=b.dataset.region; saveLocale(); panel.hidden=true;
    btn.setAttribute("aria-expanded","false"); syncLocale(); render();
  }));
  syncLocale();
}

function renderFooterModules(){
  const el=document.getElementById("foot-modules");
  if(!el) return;
  el.innerHTML=MODULES.map(m=>`<li><a href="${moduleHref(m)}">${LANG==="zh"?"模块":"Module"} ${m.num} — ${zhOf("modules",m.slug,"title",m.title)}</a></li>`).join("");
}


const app = document.getElementById("app");
const toastEl = document.getElementById("toast");
let toastTimer = null;

function num(v){ const n=parseFloat(v); return isFinite(n)?n:0; }
function fmt(n,d=0){
  if(!isFinite(n)) return "—";
  return n.toLocaleString("en-US",{minimumFractionDigits:0,maximumFractionDigits:d});
}
function seg(el, onChange){
  if(!el) return;
  const btns = el.querySelectorAll(".seg-btn");
  btns.forEach(btn=>{
    btn.addEventListener("click",()=>{
      btns.forEach(b=>b.classList.remove("is-on"));
      btn.classList.add("is-on");
      onChange(btn.dataset.val);
    });
  });
}
function toast(msg){
  toastEl.textContent=msg;
  toastEl.classList.add("is-on");
  clearTimeout(toastTimer);
  toastTimer=setTimeout(()=>toastEl.classList.remove("is-on"),1600);
}
function copyText(text){
  const done=()=>toast("Copied to clipboard");
  if(navigator.clipboard && navigator.clipboard.writeText){
    navigator.clipboard.writeText(text).then(done).catch(()=>fallback());
  }else{ fallback(); }
  function fallback(){
    const ta=document.createElement("textarea");
    ta.value=text; ta.style.position="fixed"; ta.style.opacity="0";
    document.body.appendChild(ta); ta.select();
    try{ document.execCommand("copy"); done(); }
    catch(e){ toast("Select and copy manually"); }
    document.body.removeChild(ta);
  }
}
function wireCopy(btn, getText){ if(btn) btn.addEventListener("click",()=>copyText(getText())); }
function bySlug(slug){ return TOOLS.find(t=>t.slug===slug); }
function moduleBySlug(slug){ return MODULES.find(m=>m.slug===slug); }
function staticHref(path){
  if(path === "/") return BASE || "./";
  return BASE + path.replace(/^\/+/, "").replace(/\/?$/, "/");
}
function toolHref(t){ return STATIC ? staticHref("/tools/"+t.slug+"/") : "#/tools/"+t.slug; }
function moduleHref(m){ return STATIC ? staticHref("/school/"+m.slug+"/") : "#/school/"+m.slug; }
function lessonHref(l){ return STATIC ? staticHref("/school/"+l.module.slug+"/"+l.slug+"/") : "#/school/"+l.module.slug+"/"+l.slug; }
function refHref(r){ return STATIC ? staticHref("/reference/"+r.slug+"/") : "#/reference/"+r.slug; }
function fixLinks(){
  if(!STATIC) return;
  document.querySelectorAll('a[href^="#/"]').forEach(a=>{
    a.setAttribute("href", staticHref(a.getAttribute("href").slice(1)));
  });
}

/* ============================================================
   Page builders
   ============================================================ */
function indexRow(href, numText, name, desc){
  return `<a class="index-row" href="${href}">
    <span class="index-num">${numText}</span>
    <span class="index-name">${name}</span>
    <span class="index-desc">${desc}</span>
    <span class="index-arrow">→</span>
  </a>`;
}

function moduleCard(m){
  const count=m.lessons.length;
  const title=zhOf("modules",m.slug,"title",m.title);
  const dek=zhOf("modules",m.slug,"dek",m.dek);
  return `<a class="module-card" href="${moduleHref(m)}">
    <p class="module-num">MODULE ${m.num}</p>
    <h3>${title}</h3>
    <p>${dek}</p>
    <span class="module-foot">${String(count).padStart(2,"0")} lessons →</span>
  </a>`;
}

function toolCard(t){
  const title=zhOf("tools",t.slug,"title",t.title);
  const card=zhOf("tools",t.slug,"card",t.card);
  const cat=LANG==="zh" ? (ZH_UI[t.cat]||t.cat) : t.cat;
  return `<a class="tool-card" href="${toolHref(t)}">
    <p class="tool-meta">${cat}</p>
    <h3>${title}</h3>
    <p>${card}</p>
  </a>`;
}

function relatedTools(slugList, label="Related tools"){
  const items=slugList.map(bySlug).filter(Boolean);
  return `<section class="related">
    <p class="kicker">${label}</p>
    <div class="related-grid">
      ${items.map(x=>`<a class="related-card" href="${toolHref(x)}"><b>${zhOf("tools",x.slug,"title",x.title)}</b><span>${LANG==="zh"?(ZH_UI[x.cat]||x.cat):x.cat}</span></a>`).join("")}
    </div>
  </section>`;
}

function adHTML(){ return `<div class="ad"><span>ADVERTISEMENT</span><p>Responsive display slot · 970 × 90</p></div>`; }

function homePage(){
  return {
    title:"Kitchen School — learn the kitchen, then stop guessing",
    desc:"Eighteen short lessons, ten kitchen calculators and six reference charts. Measuring, heat, pans, dough, food safety and coffee.",
    html:`
    <section class="hero">
      <div class="wrap">
        <p class="kicker">Kitchen School · English-first · no account</p>
        <div class="hero-grid">
          <h1>Learn the kitchen, then stop guessing.</h1>
          <div class="hero-side">
            <p class="hero-line">Six modules, eighteen short lessons, ten calculators and six reference charts. Read one lesson, practise it once, then use the tool.</p>
            <a class="btn" href="#/school">Start the course</a>
          </div>
        </div>
        <div class="hero-stats">
          <span><b>06</b> modules</span>
          <span><b>18</b> lessons</span>
          <span><b>10</b> tools</span>
          <span><b>06</b> charts</span>
          <span><b>0</b> sign-ups</span>
        </div>
      </div>
    </section>

    <section class="section">
      <div class="wrap">
        <div class="section-head"><h2>The curriculum</h2><a href="#/school">Full course →</a></div>
        <div class="module-grid">
          ${MODULES.map(moduleCard).join("")}
        </div>
      </div>
    </section>

    <section class="section">
      <div class="wrap">
        <div class="section-head"><h2>The toolbox</h2><a href="#/tools">All tools →</a></div>
        <div class="index">
          ${TOOLS.map((t,i)=>indexRow(toolHref(t), String(i+1).padStart(2,"0"), zhOf("tools",t.slug,"title",t.title), zhOf("tools",t.slug,"card",t.card))).join("")}
        </div>
      </div>
    </section>

    <section class="section">
      <div class="wrap">
        <div class="section-head"><h2>Reference charts</h2><a href="#/reference">All charts →</a></div>
        <div class="index">
          ${REFERENCES.map((r,i)=>indexRow(refHref(r), String(i+1).padStart(2,"0"), zhOf("refs",r.slug,"title",r.title), zhOf("refs",r.slug,"dek",r.dek))).join("")}
        </div>
      </div>
    </section>

    <section class="section" style="border-bottom:0">
      <div class="wrap">
        <div class="section-head"><h2>How to use this site</h2></div>
        <div class="card-grid">
          <div class="tool-card"><p class="tool-meta">01 — READ</p><h3>One lesson at a time</h3><p>Each lesson takes four to six minutes and ends with a small practice task.</p></div>
          <div class="tool-card"><p class="tool-meta">02 — PRACTISE</p><h3>Do it once</h3><p>Weigh one cup of flour. Run the bread test. Temp a chicken thigh. The habit is the point.</p></div>
          <div class="tool-card"><p class="tool-meta">03 — USE</p><h3>Then use the tool</h3><p>Every lesson links to the calculator or chart that does the arithmetic for you.</p></div>
          <div class="tool-card"><p class="tool-meta">04 — CHECK</p><h3>Verify with a chart</h3><p>The six reference pages are printable and kept deliberately short.</p></div>
        </div>
      </div>
    </section>`
  };
}

function schoolPage(){
  return {
    title:"The course — Kitchen School",
    desc:"Six modules, eighteen lessons: measuring, heat, pans, dough, food safety and coffee.",
    html:`
    <section class="section" style="padding-top:64px;border-bottom:0">
      <div class="wrap">
        <p class="kicker">Course · 06 modules · 18 lessons</p>
        <h1 class="page-h1">The whole course, in order.</h1>
        <p class="lede">Work top to bottom, or jump to the module you need. Every lesson is short, ends with a practice task, and links to the tool that does the math.</p>
        <div class="module-grid" style="margin-top:36px">
          ${MODULES.map(moduleCard).join("")}
        </div>
        ${adHTML()}
      </div>
    </section>`
  };
}

function modulePage(m){
  const lessons=m.lessons;
  const toolSlugs=[...new Set(lessons.flatMap(l=>l.tools))];
  const title=zhOf("modules",m.slug,"title",m.title);
  const dek=zhOf("modules",m.slug,"dek",m.dek);
  const outcome=zhOf("modules",m.slug,"outcome",m.outcome);
  return {
    title:m.title+" — Module "+m.num+" — Kitchen School",
    desc:m.dek,
    html:`
    <div class="wrap">
      <p class="crumbs"><a href="#/school">School</a><span>/</span>Module ${m.num}</p>
      <p class="kicker">Module ${m.num} · ${String(lessons.length).padStart(2,"0")} lessons</p>
      <h1 class="page-h1">${title}</h1>
      <p class="lede">${dek}</p>
      <p class="meta-line">By the end: ${outcome}</p>
      <div class="lesson-list">
        ${lessons.map((l,i)=>`<a class="lesson-row" href="${lessonHref({...l,module:m})}">
          <span class="ln">${m.num}.${i+1}</span>
          <span class="lt">${zhOf("lessons",l.slug,"title",l.title)}</span>
          <span class="lm">${l.minutes} min</span>
          <span class="ln">→</span>
        </a>`).join("")}
      </div>
      ${adHTML()}
      ${relatedTools(toolSlugs, "Tools for this module")}
      <p><a class="btn btn-ghost" href="#/school">← All modules</a></p>
    </div>`
  };
}

function lessonPage(l){
  const m=l.module;
  const all=m.lessons;
  const idx=all.findIndex(x=>x.slug===l.slug);
  const prev=idx>0 ? all[idx-1] : null;
  const next=idx<all.length-1 ? all[idx+1] : null;
  const title=zhOf("lessons",l.slug,"title",l.title);
  const dek=zhOf("lessons",l.slug,"dek",l.dek);
  const body=zhOf("lessons",l.slug,"body",l.body);
  const practice=zhOf("lessons",l.slug,"practice",l.practice);
  return {
    title:l.title+" — Lesson "+m.num+"."+(idx+1)+" — Kitchen School",
    desc:l.dek,
    html:`
    <div class="wrap">
      <p class="crumbs"><a href="#/school">School</a><span>/</span><a href="${moduleHref(m)}">${zhOf("modules",m.slug,"title",m.title)}</a><span>/</span>Lesson ${idx+1}</p>
      <p class="kicker">MODULE ${m.num} · LESSON ${String(idx+1).padStart(2,"0")}</p>
      <h1 class="page-h1">${title}</h1>
      <p class="lede">${dek}</p>
      <p class="meta-line">${l.minutes} min read · Practice included</p>
      <section class="prose">${body}</section>
      <div class="practice">
        <p class="pl">Practice</p>
        <p>${practice}</p>
      </div>
      <div class="lesson-nav">
        ${prev ? `<a href="${lessonHref({...prev,module:m})}"><span class="ln-lab">← Previous</span><span class="ln-title">${zhOf("lessons",prev.slug,"title",prev.title)}</span></a>` : `<a href="${moduleHref(m)}"><span class="ln-lab">← Back</span><span class="ln-title">${zhOf("modules",m.slug,"title",m.title)}</span></a>`}
        ${next ? `<a class="next" href="${lessonHref({...next,module:m})}"><span class="ln-lab">Next →</span><span class="ln-title">${zhOf("lessons",next.slug,"title",next.title)}</span></a>` : `<a class="next" href="#/school"><span class="ln-lab">Finish →</span><span class="ln-title">All modules</span></a>`}
      </div>
      ${adHTML()}
      ${relatedTools(l.tools, "Tools for this lesson")}
    </div>`
  };
}

function toolsPage(){
  return {
    title:"Toolbox — Kitchen School",
    desc:"Ten kitchen calculators: air fryer conversion, cups to grams, butter, pans, oven temperature, thawing, coffee, pizza dough, liquids and rice.",
    html:`
    <section class="section" style="padding-top:64px;border-bottom:0">
      <div class="wrap">
        <p class="kicker">Toolbox · 10 tools</p>
        <h1 class="page-h1">Every calculator on the site.</h1>
        <p class="lede">One page per job. Each tool runs entirely in the browser and shows the formula behind the result.</p>
        <div class="card-grid" style="margin-top:36px">
          ${TOOLS.map(toolCard).join("")}
        </div>
        ${adHTML()}
      </div>
    </section>`
  };
}

function toolPage(t){
  const title=zhOf("tools",t.slug,"title",t.title);
  const lede=zhOf("tools",t.slug,"lede",t.lede);
  const cat=LANG==="zh" ? (ZH_UI[t.cat]||t.cat) : t.cat;
  return {
    title:t.title+" — Kitchen School",
    desc:t.lede,
    html:`
    <div class="wrap">
      <p class="crumbs"><a href="#/tools">Toolbox</a><span>/</span>${cat}</p>
      <p class="kicker">${cat} · Tool</p>
      <h1 class="page-h1">${title}</h1>
      <p class="lede">${lede}</p>
      ${t.ui()}
      ${adHTML()}
      <section class="prose" id="tool-prose"></section>
      ${relatedTools(t.related)}
      <p><a class="btn btn-ghost" href="#/tools">← All tools</a></p>
    </div>`,
    mount(root){
      if(t.mount) t.mount(root);
      const prose=root.querySelector("#tool-prose");
      const zProse=zhOf("tools",t.slug,"prose","");
      prose.innerHTML = zProse || TOOL_PROSE[t.slug] || "";
    }
  };
}

function referencePage(){
  return {
    title:"Reference charts — Kitchen School",
    desc:"Six printable charts: grams per cup, oven temperatures, butter, pan sizes, meat doneness and coffee ratios.",
    html:`
    <section class="section" style="padding-top:64px;border-bottom:0">
      <div class="wrap">
        <p class="kicker">Reference · 06 charts</p>
        <h1 class="page-h1">The numbers, on one page each.</h1>
        <p class="lede">Short tables meant to be checked mid-recipe, not studied. Every chart links to the calculator that goes with it.</p>
        <div class="index" style="margin-top:36px">
          ${REFERENCES.map((r,i)=>indexRow(refHref(r), String(i+1).padStart(2,"0"), zhOf("refs",r.slug,"title",r.title), zhOf("refs",r.slug,"dek",r.dek))).join("")}
        </div>
      </div>
    </section>`
  };
}

function refDetailPage(r){
  const title=zhOf("refs",r.slug,"title",r.title);
  const dek=zhOf("refs",r.slug,"dek",r.dek);
  const intro=zhOf("refs",r.slug,"intro",r.intro);
  const notes=zhOf("refs",r.slug,"notes",r.notes);
  const headers=zhOf("refs",r.slug,"headers",r.headers);
  return {
    title:r.title+" — Kitchen School",
    desc:r.dek,
    html:`
    <div class="wrap">
      <p class="crumbs"><a href="#/reference">Reference</a><span>/</span>Chart</p>
      <p class="kicker">Printable chart</p>
      <h1 class="page-h1">${title}</h1>
      <p class="lede">${dek}</p>
      <section class="prose">
        <p>${intro}</p>
        <table class="mini-table">
          <thead><tr>${headers.map(h=>`<th>${h}</th>`).join("")}</tr></thead>
          <tbody>
            ${r.rows.map(row=>`<tr>${row.map((cell,i)=>`<td class="${r.numeric.includes(i)?"num-cell":""}">${cell}</td>`).join("")}</tr>`).join("")}
          </tbody>
        </table>
        <p>${notes}</p>
      </section>
      ${adHTML()}
      ${relatedTools(r.tools, "Use the tool")}
      <p><a class="btn btn-ghost" href="#/reference">← All charts</a></p>
    </div>`
  };
}

function aboutPage(){
  return {
    title:"About — Kitchen School",
    desc:"Why a small kitchen school exists, how it is built and how it stays free.",
    html: LANG==="zh" ? ZH.pages.about : `
    <div class="wrap">
      <p class="crumbs"><a href="#/">Home</a><span>/</span>About</p>
      <p class="kicker">About</p>
      <h1 class="page-h1">A small school with one subject.</h1>
      <p class="lede">Kitchen School is an English-first teaching site: eighteen short lessons, ten calculators, six reference charts, and no account system.</p>
      <section class="prose">
        <h2>What this is</h2>
        <p>Most kitchen mistakes are arithmetic or habit, not talent. The course covers six: measuring, heat, pans, dough, food safety and coffee. Each lesson ends with one small practice task.</p>
        <h2>How it is built</h2>
        <p>A static site. No framework, no database, no accounts. Every calculation runs locally in your browser, which is also why the pages load quickly and keep working once opened.</p>
        <h2>How it stays free</h2>
        <p>The site is free to read. When display advertising is enabled, ads will be clearly marked and kept out of the calculators. There are no paywalls, no accounts and no affiliate links in this build.</p>
        <h2>Limits</h2>
        <p>These are estimates and standard references, not lab measurements. Ovens, air fryers and pans vary. For safety, the site follows USDA rates, but your own fridge and thermometer still get the final say.</p>
      </section>
    </div>`
  };
}

function privacyPage(){
  return {
    title:"Privacy — Kitchen School",
    desc:"What this site collects, and what stays on your device.",
    html: LANG==="zh" ? ZH.pages.privacy : `
    <div class="wrap">
      <p class="crumbs"><a href="#/">Home</a><span>/</span>Privacy</p>
      <p class="kicker">Privacy</p>
      <h1 class="page-h1">Nothing collected, nothing sold.</h1>
      <p class="lede">A static site. Calculations and typed numbers stay in your browser.</p>
      <section class="prose">
        <h2>What we collect</h2>
        <p>No account, no email capture and no analytics script. The only thing stored is one local preference: your language and region choice, kept in your browser so the site remembers it next time.</p>
        <h2>Advertising</h2>
        <p>No ad code runs on this build. If display ads are enabled later, Google and its partners may set cookies and use device identifiers; a consent banner and a full advertising disclosure will be added before any ad code runs.</p>
        <h2>Your inputs</h2>
        <p>Numbers you type are used to calculate a result on your device. They are not transmitted, logged or stored.</p>
        <h2>Changes</h2>
        <p>If the policy changes, the date at the bottom of this page changes with it. Last updated: November 2026.</p>
      </section>
    </div>`
  };
}

function notFoundPage(){
  return {
    title:"Page not found — Kitchen School",
    desc:"That page does not exist.",
    html:`
    <div class="wrap">
      <p class="kicker" style="margin-top:64px">404</p>
      <h1 class="page-h1">This page is not here.</h1>
      <p class="lede">The link may be old, or the page may have moved. Everything the site offers is listed below.</p>
      <p style="margin-top:28px"><a class="btn" href="#/school">The course</a> <a class="btn btn-ghost" href="#/tools">Toolbox</a></p>
    </div>`
  };
}

/* ============================================================
   Router
   ============================================================ */
function parsePath(){
  if(STATIC && STATIC_PATH) return STATIC_PATH;
  const raw=(location.hash||"").replace(/^#/,""); return raw || "/";
}

function resolve(path){
  if(path==="/" || path==="") return homePage();
  if(path==="/school") return schoolPage();
  if(path==="/tools") return toolsPage();
  if(path==="/reference") return referencePage();
  if(path==="/about") return aboutPage();
  if(path==="/privacy") return privacyPage();

  const modMatch=path.match(/^\/school\/([^/]+)$/);
  if(modMatch){ const m=moduleBySlug(modMatch[1]); return m ? modulePage(m) : notFoundPage(); }
  const lessonMatch=path.match(/^\/school\/([^/]+)\/([^/]+)$/);
  if(lessonMatch){
    const m=moduleBySlug(lessonMatch[1]);
    const l=m && m.lessons.find(x=>x.slug===lessonMatch[2]);
    return l ? lessonPage({...l, module:m}) : notFoundPage();
  }
  const toolMatch=path.match(/^\/tools\/([^/]+)$/);
  if(toolMatch){ const t=bySlug(toolMatch[1]); return t ? toolPage(t) : notFoundPage(); }
  const refMatch=path.match(/^\/reference\/([^/]+)$/);
  if(refMatch){ const r=REFERENCES.find(x=>x.slug===refMatch[1]); return r ? refDetailPage(r) : notFoundPage(); }
  return notFoundPage();
}

function updateNav(path){
  document.querySelectorAll("#nav a").forEach(a=>{
    const target=a.dataset.nav;
    const on = path===target
      || (target==="/school" && path.startsWith("/school"))
      || (target==="/tools" && path.startsWith("/tools"))
      || (target==="/reference" && path.startsWith("/reference"));
    a.classList.toggle("is-on",on);
  });
}

function render(){
  const path=parsePath();
  const page=resolve(path);
  app.innerHTML=page.html;
  if(page.mount) page.mount(app);
  const meta=document.querySelector('meta[name="description"]');
  if(meta) meta.setAttribute("content",page.desc||"");
  updateNav(path);
  renderFooterModules();
  translateDOM(app);
  translateDOM(document.querySelector(".site-head"));
  translateDOM(document.querySelector(".site-foot"));
  if(LANG==="zh"){
    const h1=app.querySelector("h1");
    document.title=(h1 ? h1.textContent.trim() : "厨房学校") + " — 厨房学校";
  }else{
    document.title=page.title;
  }
  fixLinks();
  syncLocale();
  window.scrollTo(0,0);
}

/* ============================================================
   Boot
   ============================================================ */
initLocale();
if(!STATIC) window.addEventListener("hashchange",render);
render();
